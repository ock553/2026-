#!/usr/bin/env python3
"""
NEO-M8N GPS 模块测试脚本
串口：/dev/ttyS3，默认波特率 9600
功能：原始NMEA输出 + 解析 GGA/RMC 语句
"""

import sys
import time
import serial

# ── 配置 ───────────────────────────────────────────────
PORT     = "/dev/ttyS3"
BAUDRATE = 9600
TIMEOUT  = 2.0   # 秒


# ── NMEA 解析 ──────────────────────────────────────────
def nmea_checksum_ok(line: str) -> bool:
    """验证 NMEA 校验和（$....*XX）"""
    if '*' not in line:
        return False
    try:
        data, chk = line[1:].rsplit('*', 1)
        calc = 0
        for c in data:
            calc ^= ord(c)
        return calc == int(chk.strip(), 16)
    except Exception:
        return False


def parse_ddmm(raw: str, hemi: str) -> float:
    """将 DDMM.MMMMM 格式转换为十进制度"""
    if not raw:
        return float('nan')
    dot = raw.index('.')
    deg = float(raw[:dot - 2])
    minutes = float(raw[dot - 2:])
    result = deg + minutes / 60.0
    if hemi in ('S', 'W'):
        result = -result
    return result


def parse_gga(fields):
    """解析 $GPGGA / $GNGGA"""
    if len(fields) < 10:
        return None
    fix = int(fields[6]) if fields[6] else 0
    if fix == 0:
        return {"type": "GGA", "fix": False}
    return {
        "type"    : "GGA",
        "fix"     : True,
        "utc"     : fields[1],
        "lat"     : parse_ddmm(fields[2], fields[3]),
        "lon"     : parse_ddmm(fields[4], fields[5]),
        "quality" : fix,
        "sats"    : int(fields[7]) if fields[7] else 0,
        "hdop"    : float(fields[8]) if fields[8] else 0.0,
        "alt_m"   : float(fields[9]) if fields[9] else 0.0,
    }


def parse_rmc(fields):
    """解析 $GPRMC / $GNRMC"""
    if len(fields) < 9:
        return None
    valid = fields[2] == 'A'
    if not valid:
        return {"type": "RMC", "valid": False}
    return {
        "type"    : "RMC",
        "valid"   : True,
        "utc"     : fields[1],
        "lat"     : parse_ddmm(fields[3], fields[4]),
        "lon"     : parse_ddmm(fields[5], fields[6]),
        "speed_kn": float(fields[7]) if fields[7] else 0.0,
        "course"  : float(fields[8]) if fields[8] else 0.0,
        "date"    : fields[9] if len(fields) > 9 else "",
    }


def process_line(line: str):
    """处理单条 NMEA 语句，返回解析结果或 None"""
    line = line.strip()
    if not line.startswith('$'):
        return None
    if not nmea_checksum_ok(line):
        return None
    # 去掉校验和部分
    clean = line.split('*')[0]
    fields = clean.split(',')
    tag = fields[0][1:]  # 去掉 $

    if tag in ('GPGGA', 'GNGGA'):
        return parse_gga(fields)
    if tag in ('GPRMC', 'GNRMC'):
        return parse_rmc(fields)
    return None


# ── 打印 ───────────────────────────────────────────────
def print_gga(d):
    if not d.get('fix'):
        print("  [GGA] 无定位")
        return
    print(f"  [GGA] 纬度={d['lat']:.6f}° 经度={d['lon']:.6f}°  "
          f"海拔={d['alt_m']:.1f}m  卫星数={d['sats']}  HDOP={d['hdop']:.1f}  UTC={d['utc']}")


def print_rmc(d):
    if not d.get('valid'):
        print("  [RMC] 数据无效（未定位）")
        return
    speed_kmh = d['speed_kn'] * 1.852
    print(f"  [RMC] 纬度={d['lat']:.6f}° 经度={d['lon']:.6f}°  "
          f"速度={speed_kmh:.1f}km/h  航向={d['course']:.1f}°  日期={d['date']}  UTC={d['utc']}")


# ── 主流程 ─────────────────────────────────────────────
def main():
    port = sys.argv[1] if len(sys.argv) > 1 else PORT
    baud = int(sys.argv[2]) if len(sys.argv) > 2 else BAUDRATE

    print(f"打开串口 {port} @ {baud}bps ...")
    try:
        ser = serial.Serial(port, baud, timeout=TIMEOUT)
    except serial.SerialException as e:
        print(f"[错误] 无法打开串口：{e}")
        sys.exit(1)

    print("等待 GPS 数据（Ctrl+C 退出）...\n")

    raw_count  = 0
    gga_count  = 0
    rmc_count  = 0
    start_time = time.time()

    try:
        buf = b""
        while True:
            chunk = ser.read(256)
            if not chunk:
                continue
            buf += chunk
            while b'\n' in buf:
                line_bytes, buf = buf.split(b'\n', 1)
                try:
                    line = line_bytes.decode('ascii', errors='ignore')
                except Exception:
                    continue

                raw_count += 1
                # 原始输出（前30行展示，之后只打印解析结果）
                if raw_count <= 30:
                    print(f"[RAW] {line.strip()}")

                result = process_line(line)
                if result is None:
                    continue

                if result['type'] == 'GGA':
                    gga_count += 1
                    print_gga(result)
                elif result['type'] == 'RMC':
                    rmc_count += 1
                    print_rmc(result)

                # 每10秒打印统计
                elapsed = time.time() - start_time
                if elapsed > 0 and (gga_count + rmc_count) % 20 == 0:
                    print(f"\n  -- 统计：运行 {elapsed:.0f}s  原始行={raw_count}  GGA={gga_count}  RMC={rmc_count} --\n")

    except KeyboardInterrupt:
        elapsed = time.time() - start_time
        print(f"\n\n已退出。运行 {elapsed:.1f}s，"
              f"原始行={raw_count}，GGA={gga_count}，RMC={rmc_count}")
    finally:
        ser.close()


if __name__ == '__main__':
    main()
