"""
老人前倾检测 - YOLOv8 Pose on RK3588
算力策略：NPU_CORE_0_1_2 三核联合（6TOPS全开），二阶段推理提升关键点精度

推理流程（每帧）：
  阶段1：全图 640×640 推理 → 定位人体框（粗检测）
  阶段2：ROI 放大至 640×640 再推理 → 精细关键点（人体占满输入）

模型输出格式 (1, 17, 8400)：
  d[0]  cx   d[1]  cy   d[2]  w    d[3]  h
  d[4]  obj_conf（RKNN转换后全为0，使用几何约束）
  d[5]  kpt0_x  d[6]  kpt0_y  d[7]  kpt0_conf  ← 鼻子
  d[8]  kpt1_x  d[9]  kpt1_y  d[10] kpt1_conf  ← 左耳
  d[11] kpt2_x  d[12] kpt2_y  d[13] kpt2_conf  ← 左肩
  d[14] kpt3_x  d[15] kpt3_y  d[16] kpt3_conf  ← 右肩
"""
import cv2
import numpy as np
import math
import time
import threading
import socketserver
import http.server
import json
import urllib.request
from queue import Queue
from concurrent.futures import ThreadPoolExecutor, as_completed
from rknnlite.api import RKNNLite

# ─── 配置 ────────────────────────────────────────────────────
MODEL_PATH  = "/home/elf/best.rknn"
CAMERA_ID   = "/dev/video21"
IMG_SIZE    = 640
MJPEG_PORT  = 8090   # 视频流端口，浏览器 <img> 直连，不走 WebSocket
# 三核联合推理（NPU_CORE_0_1_2）下最优并发数：
# 一个线程在 NPU 推理，另外两个在预处理/后处理，流水线满负荷
TPEs        = 3

OBJ_THRESH   = 0.25
NMS_THRESH   = 0.45
KPT_THRESH   = 0.3

WARN_ANGLE  = 30.0
ALARM_ANGLE = 50.0
MIN_BOX_H   = 80     # 降低以减少近距离漏检（原120）
MIN_SHO_SPAN = 25    # 略微放宽（原30）
KPT_MARGIN  = 0.20

# 关键点置信度总和阈值：若模型输出kpt_conf有意义可调高（如0.5），
# 若RKNN转换后全为0则保持0.0（禁用此过滤）
KPT_CONF_SUM_MIN = 0.0

# 粗检测最低质量分，低于此分不进行ROI二阶段（过滤明显的误检框）
MIN_COARSE_SCORE = 0.12

# ROI 精细化推理的扩展边距（相对于粗检测框的比例）
ROI_MARGIN_TOP    = 0.35   # 头部方向多留空间
ROI_MARGIN_BOTTOM = 0.15
ROI_MARGIN_SIDE   = 0.25   # 左右留手臂空间

# 时序平滑
ANGLE_EMA_ALPHA  = 0.35
ANGLE_MISS_RESET = 8

KPT_NOSE, KPT_LEAR, KPT_LSHO, KPT_RSHO = 0, 1, 2, 3
KPT_COLORS = [(0, 255, 255), (0, 200, 255), (0, 255, 0), (0, 255, 0)]
KPT_NAMES  = ["鼻子", "左耳", "左肩", "右肩"]

# ─── MJPEG 视频流服务器 ──────────────────────────────────────
# 推理线程将处理后的帧写入此缓冲，HTTP 服务线程持续推送给浏览器

_mjpeg_frame = None
_mjpeg_lock  = threading.Lock()

# 最新姿态数据（主循环写入，发送线程读取）
_latest_pose      = {"type": "pose", "angle": -1.0, "status": "none"}
_latest_pose_lock = threading.Lock()

class _MJPEGHandler(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        self.send_response(200)
        self.send_header('Content-Type',  'multipart/x-mixed-replace; boundary=--jpgboundary')
        self.send_header('Cache-Control', 'no-cache')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        try:
            while True:
                with _mjpeg_lock:
                    frame = _mjpeg_frame
                if frame is not None:
                    self.wfile.write(b'--jpgboundary\r\nContent-Type: image/jpeg\r\n\r\n')
                    self.wfile.write(frame)
                    self.wfile.write(b'\r\n')
                time.sleep(1.0 / 30)
        except Exception:
            pass

    def log_message(self, *args):
        pass   # 静默 HTTP 日志

class _ThreadingServer(socketserver.ThreadingMixIn, socketserver.TCPServer):
    allow_reuse_address = True
    daemon_threads      = True

def _start_mjpeg():
    server = _ThreadingServer(("", MJPEG_PORT), _MJPEGHandler)
    print(f"[MJPEG] 视频流已启动 http://0.0.0.0:{MJPEG_PORT}/stream")
    server.serve_forever()

def _pose_sender():
    """以 10Hz 向 bridge.py 的 POST /pose 推送姿态数据"""
    url = "http://127.0.0.1:8080/pose"
    while True:
        try:
            with _latest_pose_lock:
                payload = json.dumps(_latest_pose).encode()
            req = urllib.request.Request(url, data=payload,
                                         headers={"Content-Type": "application/json"})
            urllib.request.urlopen(req, timeout=1)
        except Exception:
            pass
        time.sleep(0.1)

def _push_frame(bgr_frame):
    """将 BGR 帧压缩为 JPEG 写入缓冲（供 MJPEG 服务推送）"""
    global _mjpeg_frame
    ret, buf = cv2.imencode('.jpg', bgr_frame, [cv2.IMWRITE_JPEG_QUALITY, 80])
    if ret:
        with _mjpeg_lock:
            _mjpeg_frame = buf.tobytes()

def _initRKNN(model, core_id):
    rknn = RKNNLite()
    if rknn.load_rknn(model) != 0:
        print("Load RKNN model failed"); exit(1)
    # 三核联合：每个实例独占全部 6TOPS，不再轮询单核
    if rknn.init_runtime(core_mask=RKNNLite.NPU_CORE_0_1_2) != 0:
        print("Init runtime failed"); exit(1)
    return rknn

class rknnPoolExecutor:
    def __init__(self, rknnModel, TPEs, func):
        self.TPEs     = TPEs
        self.queue    = Queue()
        self.rknnPool = [_initRKNN(rknnModel, i) for i in range(TPEs)]
        self.pool     = ThreadPoolExecutor(max_workers=TPEs)
        self.func     = func
        self.num      = 0

    def put(self, frame):
        self.queue.put(self.pool.submit(
            self.func, self.rknnPool[self.num % self.TPEs], frame))
        self.num += 1

    def get(self):
        if self.queue.empty():
            return None, False
        temp = [self.queue.get()]
        for f in as_completed(temp):
            return f.result(), True

    def release(self):
        self.pool.shutdown()
        for r in self.rknnPool:
            r.release()


# ─── 预处理 ──────────────────────────────────────────────────

def letterbox(im, new_shape=(640, 640)):
    shape = im.shape[:2]
    r = min(new_shape[0] / shape[0], new_shape[1] / shape[1])
    new_unpad = int(round(shape[1] * r)), int(round(shape[0] * r))
    dw = (new_shape[1] - new_unpad[0]) / 2
    dh = (new_shape[0] - new_unpad[1]) / 2
    if shape[::-1] != new_unpad:
        im = cv2.resize(im, new_unpad, interpolation=cv2.INTER_LINEAR)
    top    = int(round(dh - 0.1));  bottom = int(round(dh + 0.1))
    left   = int(round(dw - 0.1));  right  = int(round(dw + 0.1))
    im = cv2.copyMakeBorder(im, top, bottom, left, right,
                             cv2.BORDER_CONSTANT, value=(114, 114, 114))
    return im, (r, r), (left, top)


# ─── NMS ─────────────────────────────────────────────────────

def nms_boxes(x1, y1, x2, y2, scores):
    areas = (x2 - x1) * (y2 - y1)
    order = scores.argsort()[::-1]
    keep = []
    while order.size > 0:
        i = order[0]
        keep.append(i)
        ix1 = np.maximum(x1[i], x1[order[1:]])
        iy1 = np.maximum(y1[i], y1[order[1:]])
        ix2 = np.minimum(x2[i], x2[order[1:]])
        iy2 = np.minimum(y2[i], y2[order[1:]])
        inter = np.maximum(0.0, ix2 - ix1) * np.maximum(0.0, iy2 - iy1)
        iou   = inter / (areas[i] + areas[order[1:]] - inter + 1e-6)
        order = order[np.where(iou <= NMS_THRESH)[0] + 1]
    return keep


# ─── 几何约束 + 质量评分 ─────────────────────────────────────

def _geo_mask(d):
    nose_y = d[6];  lear_y = d[9]
    lsho_x = d[11]; lsho_y = d[12]
    rsho_x = d[14]; rsho_y = d[15]

    head_y    = np.minimum(nose_y, lear_y)
    mid_sho_y = (lsho_y + rsho_y) * 0.5
    sho_span  = np.abs(lsho_x - rsho_x)
    head_gap  = mid_sho_y - head_y
    sho_level = np.abs(lsho_y - rsho_y)

    # 头部必须在框的上半部分（头部关键点 y < 框中心 y - 10%×框高）
    # 区分真实人体与背景误检：环境物体的"头部"预测点可能落在框下半部
    head_in_upper = head_y < (d[1] - d[3] * 0.10)

    # 框宽高比约束：坐姿人体框高≥宽（宽高比<1.6），过滤横向环境结构
    aspect_ok = (d[2] / (d[3] + 1e-6)) < 1.6

    # 关键点置信度过滤（KPT_CONF_SUM_MIN=0时禁用）
    if KPT_CONF_SUM_MIN > 0:
        kpt_conf_sum = d[7] + d[10] + d[13] + d[16]
        kpt_ok = kpt_conf_sum >= KPT_CONF_SUM_MIN
    else:
        kpt_ok = np.ones(d.shape[1], dtype=bool)

    return (
        (d[3] >= MIN_BOX_H)        &
        (head_y < mid_sho_y)       &
        (head_gap  > d[3] * 0.10)  &  # 略微放宽（原0.12）
        (sho_level < d[3] * 0.25)  &  # 略微放宽（原0.22）
        (sho_span  > MIN_SHO_SPAN) &
        (sho_span  > d[2] * 0.12)  &  # 略微放宽（原0.15）
        head_in_upper              &
        aspect_ok                  &
        kpt_ok
    )


def _geo_quality(d, idxs):
    """几何质量评分：头肩距比(0.40) + 肩宽比(0.25) + 居中性(0.15) + 关键点置信度(0.20)"""
    bh     = d[3, idxs];  bw    = d[2, idxs]
    cx     = d[0, idxs]
    nose_y = d[6, idxs];  lear_y = d[9, idxs]
    lsho_x = d[11, idxs]; lsho_y = d[12, idxs]
    rsho_x = d[14, idxs]; rsho_y = d[15, idxs]

    head_y    = np.minimum(nose_y, lear_y)
    mid_sho_y = (lsho_y + rsho_y) * 0.5
    mid_sho_x = (lsho_x + rsho_x) * 0.5
    sho_span  = np.abs(lsho_x - rsho_x)
    head_gap  = np.maximum(0.0, mid_sho_y - head_y)

    head_ratio   = np.clip(head_gap / (bh + 1e-6), 0.0, 0.5) * 2.0
    span_ratio   = np.clip(sho_span / (bw + 1e-6), 0.0, 0.6) / 0.6
    center_err   = np.abs(mid_sho_x - cx) / (bw + 1e-6)
    center_score = np.clip(1.0 - center_err * 2, 0.0, 1.0)

    # 关键点置信度评分（若模型输出可信则提升真实人体排名）
    kpt_conf_sum = d[7, idxs] + d[10, idxs] + d[13, idxs] + d[16, idxs]
    kpt_score    = np.clip(kpt_conf_sum / 2.0, 0.0, 1.0)

    return head_ratio * 0.40 + span_ratio * 0.25 + center_score * 0.15 + kpt_score * 0.20


# ─── 后处理 ──────────────────────────────────────────────────

def postprocess(outputs, ratio, pad, orig_shape, _diag=[0]):
    d = outputs[0][0]   # (17, 8400)
    conf = d[4]

    # 诊断：首次运行打印置信度范围，帮助调参
    _diag[0] += 1
    if _diag[0] == 1:
        kc_max = max(float(d[7].max()), float(d[10].max()),
                     float(d[13].max()), float(d[16].max()))
        print(f"[诊断] obj_conf max={float(conf.max()):.4f}  "
              f"kpt_conf max={kc_max:.4f}  "
              f"(若kpt_conf max>0.3可将KPT_CONF_SUM_MIN调为0.5)")

    use_conf = float(conf.max()) > OBJ_THRESH

    valid_mask = conf > OBJ_THRESH if use_conf else _geo_mask(d)
    if not valid_mask.any():
        return []

    idxs = np.where(valid_mask)[0]
    cx_ = d[0, idxs];  cy_ = d[1, idxs]
    bw_ = d[2, idxs];  bh_ = d[3, idxs]
    x1_ = cx_ - bw_ * 0.5;  y1_ = cy_ - bh_ * 0.5
    x2_ = cx_ + bw_ * 0.5;  y2_ = cy_ + bh_ * 0.5

    scores_ = conf[idxs] if use_conf else _geo_quality(d, idxs)
    keep    = nms_boxes(x1_, y1_, x2_, y2_, scores_)

    oh, ow = orig_shape[:2]
    r, (pl, pt) = ratio[0], pad
    results = []

    for ki in keep:
        idx  = idxs[ki]
        bx1  = (x1_[ki] - pl) / r;  by1 = (y1_[ki] - pt) / r
        bx2  = (x2_[ki] - pl) / r;  by2 = (y2_[ki] - pt) / r
        bw_o = bx2 - bx1;           bh_o = by2 - by1

        box = [int(max(0, bx1)), int(max(0, by1)),
               int(min(ow, bx2)), int(min(oh, by2))]

        kpts = []
        for k in range(4):
            kx = (d[5 + k*3, idx] - pl) / r
            ky = (d[6 + k*3, idx] - pt) / r
            kc_raw = float(d[7 + k*3, idx])
            if use_conf:
                kc = kc_raw if kc_raw > 0.01 else 0.0
            else:
                in_x = (bx1 - bw_o * KPT_MARGIN) <= kx <= (bx2 + bw_o * KPT_MARGIN)
                in_y = (by1 - bh_o * KPT_MARGIN) <= ky <= (by2 + bh_o * KPT_MARGIN)
                kc = 0.7 if (in_x and in_y) else 0.1
            kpts.append((kx, ky, kc))

        results.append({'box': box, 'kpts': kpts,
                        'score': float(scores_[ki]), 'use_conf': use_conf})
    return results


# ─── 前倾角计算 ──────────────────────────────────────────────

def calc_lean_angle(kpts):
    nose, lear = kpts[KPT_NOSE], kpts[KPT_LEAR]
    lsho, rsho = kpts[KPT_LSHO], kpts[KPT_RSHO]

    if lsho[2] < KPT_THRESH or rsho[2] < KPT_THRESH:
        return None

    mid_x = (lsho[0] + rsho[0]) * 0.5
    mid_y = (lsho[1] + rsho[1]) * 0.5

    if nose[2] >= KPT_THRESH and lear[2] >= KPT_THRESH:
        total_c = nose[2] + lear[2]
        hx = (nose[0] * nose[2] + lear[0] * lear[2]) / total_c
        hy = (nose[1] * nose[2] + lear[1] * lear[2]) / total_c
    elif nose[2] >= KPT_THRESH:
        hx, hy = nose[0], nose[1]
    elif lear[2] >= KPT_THRESH:
        hx, hy = lear[0], lear[1]
    else:
        return None

    if hy >= mid_y:
        return None

    dx, dy = hx - mid_x, hy - mid_y
    dist = math.hypot(dx, dy)
    if dist < 5:
        return None

    angle = math.degrees(math.acos(max(-1.0, min(1.0, (-dy) / dist))))
    return angle, (int(hx), int(hy)), (int(mid_x), int(mid_y))


# ─── 时序平滑（EMA）─────────────────────────────────────────

class AngleSmoother:
    def __init__(self, alpha=ANGLE_EMA_ALPHA, miss_reset=ANGLE_MISS_RESET):
        self.alpha      = alpha
        self.miss_reset = miss_reset
        self._val       = None
        self._miss      = 0

    def update(self, angle):
        if angle is None:
            self._miss += 1
            if self._miss >= self.miss_reset:
                self._val = None
            return self._val, False
        self._miss = 0
        if self._val is None:
            self._val = angle
        else:
            self._val = self.alpha * angle + (1 - self.alpha) * self._val
        return self._val, True


# ─── 绘制 ────────────────────────────────────────────────────

def draw(frame, det, label_suffix=""):
    x1, y1, x2, y2 = det['box']
    kpts = det['kpts']

    cv2.rectangle(frame, (x1, y1), (x2, y2), (160, 160, 160), 1)
    for k, (kx, ky, kc) in enumerate(kpts):
        color  = KPT_COLORS[k] if kc >= KPT_THRESH else (80, 80, 80)
        radius = 7 if kc >= KPT_THRESH else 4
        cv2.circle(frame, (int(kx), int(ky)), radius, color, -1)
        cv2.putText(frame, KPT_NAMES[k], (int(kx)+8, int(ky)-4),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 1)

    mode = "conf" if det.get('use_conf') else "geo"
    cv2.putText(frame, f"{mode}:{det['score']:.2f}{label_suffix}",
                (x1, y2+16), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (0, 200, 200), 1)

    info = calc_lean_angle(kpts)
    if info is None:
        return None

    angle, head_pt, mid_pt = info
    cv2.line(frame, head_pt, mid_pt, (255, 200, 0), 2)
    ref = max(20, int(math.hypot(head_pt[0]-mid_pt[0], head_pt[1]-mid_pt[1])))
    cv2.line(frame, mid_pt, (mid_pt[0], mid_pt[1]-ref), (80, 80, 80), 1)

    if angle >= ALARM_ANGLE:
        color, label = (0, 0, 255),   f"报警! {angle:.0f}deg"
    elif angle >= WARN_ANGLE:
        color, label = (0, 100, 255), f"警告 {angle:.0f}deg"
    else:
        color, label = (0, 200, 0),   f"正常 {angle:.0f}deg"

    (tw, th), _ = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.85, 2)
    cv2.rectangle(frame, (x1, y1-th-14), (x1+tw+8, y1), color, -1)
    cv2.putText(frame, label, (x1+4, y1-4),
                cv2.FONT_HERSHEY_SIMPLEX, 0.85, (255, 255, 255), 2)
    return info


def draw_overlay(frame, angle_info, fps):
    h, w = frame.shape[:2]
    cv2.rectangle(frame, (0, h-48), (w, h), (25, 25, 25), -1)
    cv2.putText(frame, f"FPS {fps:.1f}", (10, h-12),
                cv2.FONT_HERSHEY_SIMPLEX, 0.7, (180, 180, 180), 1)

    if angle_info:
        angle = angle_info[0]
        if angle >= ALARM_ANGLE:
            ov = frame.copy()
            cv2.rectangle(ov, (0, h//2-45), (w, h//2+45), (0, 0, 180), -1)
            cv2.addWeighted(ov, 0.6, frame, 0.4, 0, frame)
            txt = f"!!! 前倾报警 {angle:.0f}deg !!!"
            (tw, th), _ = cv2.getTextSize(txt, cv2.FONT_HERSHEY_SIMPLEX, 1.8, 3)
            cv2.putText(frame, txt, ((w-tw)//2, h//2+th//2),
                        cv2.FONT_HERSHEY_SIMPLEX, 1.8, (255, 255, 255), 3)
            cv2.rectangle(frame, (0,0), (w-1,h-1), (0,0,255), 6)
            status, color = f"报警  {angle:.1f}deg", (60, 60, 255)
        elif angle >= WARN_ANGLE:
            ov = frame.copy()
            cv2.rectangle(ov, (0, h//2-45), (w, h//2+45), (0, 80, 200), -1)
            cv2.addWeighted(ov, 0.6, frame, 0.4, 0, frame)
            txt = f"! 前倾警告 {angle:.0f}deg !"
            (tw, th), _ = cv2.getTextSize(txt, cv2.FONT_HERSHEY_SIMPLEX, 1.8, 3)
            cv2.putText(frame, txt, ((w-tw)//2, h//2+th//2),
                        cv2.FONT_HERSHEY_SIMPLEX, 1.8, (255, 255, 0), 3)
            cv2.rectangle(frame, (0,0), (w-1,h-1), (0,120,255), 6)
            status, color = f"警告  {angle:.1f}deg", (60, 140, 255)
        else:
            txt = f"正常坐姿  {angle:.1f}deg"
            (tw, th), _ = cv2.getTextSize(txt, cv2.FONT_HERSHEY_SIMPLEX, 1.0, 2)
            cv2.rectangle(frame, (10, 10), (tw+30, th+24), (0, 140, 0), -1)
            cv2.putText(frame, txt, (18, th+16),
                        cv2.FONT_HERSHEY_SIMPLEX, 1.0, (255, 255, 255), 2)
            status, color = f"正常  {angle:.1f}deg", (60, 210, 60)
    else:
        status, color = "未检测到人体", (100, 100, 100)

    cv2.putText(frame, status, (140, h-12),
                cv2.FONT_HERSHEY_SIMPLEX, 0.85, color, 2)


# ─── 推理函数（二阶段：全图粗检测 → ROI 精细化）─────────────

def myFunc(rknn_lite, frame):
    h_frame, w_frame = frame.shape[:2]

    # ── 阶段1：全图推理，定位人体框 ──────────────────────────
    img_full = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    img_full_lb, ratio_full, pad_full = letterbox(img_full)
    out1 = rknn_lite.inference(inputs=[np.expand_dims(img_full_lb, 0)],
                               data_format=['nhwc'])
    dets = postprocess(out1, ratio_full, pad_full, frame.shape)

    if not dets:
        return frame, None

    # 粗检测选几何质量最高的候选框
    best_coarse = max(dets, key=lambda x: x['score'])
    # 质量分过低说明是误检（环境背景），直接跳过不框
    if best_coarse['score'] < MIN_COARSE_SCORE:
        return frame, None
    x1, y1, x2, y2 = best_coarse['box']
    bw, bh = x2 - x1, y2 - y1

    # 画出其余候选（调试用）
    for det in dets:
        if det is not best_coarse:
            dx1, dy1, dx2, dy2 = det['box']
            cv2.rectangle(frame, (dx1, dy1), (dx2, dy2), (60, 60, 60), 1)

    # ── 阶段2：ROI 精细化推理 ──────────────────────────────────
    # 裁剪人体框并加扩展边距，放大至 640×640 再推理
    # 人体占满输入分辨率，关键点定位精度显著提升
    rx1 = max(0,       int(x1 - bw * ROI_MARGIN_SIDE))
    ry1 = max(0,       int(y1 - bh * ROI_MARGIN_TOP))
    rx2 = min(w_frame, int(x2 + bw * ROI_MARGIN_SIDE))
    ry2 = min(h_frame, int(y2 + bh * ROI_MARGIN_BOTTOM))

    roi = frame[ry1:ry2, rx1:rx2]

    if roi.size < 400:
        # ROI 过小（异常），回退到粗检测结果
        angle_info = draw(frame, best_coarse, " [粗]")
        return frame, angle_info

    img_roi = cv2.cvtColor(roi, cv2.COLOR_BGR2RGB)
    img_roi_lb, ratio_roi, pad_roi = letterbox(img_roi)
    out2 = rknn_lite.inference(inputs=[np.expand_dims(img_roi_lb, 0)],
                               data_format=['nhwc'])
    dets_roi = postprocess(out2, ratio_roi, pad_roi, roi.shape)

    if dets_roi:
        # ROI 推理成功：将关键点坐标映射回原图坐标系
        refined = max(dets_roi, key=lambda x: x['score'])
        refined['kpts'] = [(kx + rx1, ky + ry1, kc)
                           for kx, ky, kc in refined['kpts']]
        rb = refined['box']
        refined['box'] = [rb[0]+rx1, rb[1]+ry1, rb[2]+rx1, rb[3]+ry1]
        angle_info = draw(frame, refined, " [ROI]")
    else:
        # ROI 推理无结果（少见），回退粗检测
        angle_info = draw(frame, best_coarse, " [粗]")

    return frame, angle_info


# ─── 主程序 ──────────────────────────────────────────────────

def main():
    # 启动 MJPEG 视频流服务（浏览器直连，不依赖 ROS）
    threading.Thread(target=_start_mjpeg, daemon=True).start()
    # 启动姿态数据推送线程（10Hz POST → bridge.py → WebSocket）
    threading.Thread(target=_pose_sender, daemon=True).start()

    print("初始化 RKNN 线程池（三核联合 NPU_CORE_0_1_2，6TOPS）...")
    pool     = rknnPoolExecutor(rknnModel=MODEL_PATH, TPEs=TPEs, func=myFunc)
    smoother = AngleSmoother()
    print("模型就绪，二阶段推理已启用")

    cap = cv2.VideoCapture(CAMERA_ID)
    if not cap.isOpened():
        print(f"无法打开摄像头 {CAMERA_ID}"); pool.release(); return

    if cap.isOpened():
        for i in range(TPEs + 1):
            ret, frame = cap.read()
            if not ret:
                cap.release(); del pool; return
            pool.put(frame)

    out_win = "老人前倾检测"
    cv2.namedWindow(out_win, cv2.WINDOW_NORMAL)
    cv2.setWindowProperty(out_win, cv2.WND_PROP_FULLSCREEN, cv2.WINDOW_FULLSCREEN)

    frames, loopTime, initTime = 0, time.time(), time.time()
    fps = 0.0

    print("运行中... 按 q 退出")
    while cap.isOpened():
        frames += 1
        ret, frame = cap.read()
        if not ret:
            break
        pool.put(frame)

        result, flag = pool.get()
        if not flag:
            break
        out_frame, raw_angle_info = result

        # 时序平滑
        raw_angle = raw_angle_info[0] if raw_angle_info else None
        smooth_angle, detected = smoother.update(raw_angle)

        if detected and raw_angle_info:
            smooth_info = (smooth_angle, raw_angle_info[1], raw_angle_info[2])
        elif smooth_angle is not None:
            smooth_info = (smooth_angle, None, None)
        else:
            smooth_info = None

        # 更新姿态状态供发送线程推送
        if smooth_angle is not None:
            if smooth_angle >= ALARM_ANGLE:
                pose_status = "alarm"
            elif smooth_angle >= WARN_ANGLE:
                pose_status = "warning"
            else:
                pose_status = "normal"
            with _latest_pose_lock:
                _latest_pose.update({"angle": round(smooth_angle, 1), "status": pose_status})
        else:
            with _latest_pose_lock:
                _latest_pose.update({"angle": -1.0, "status": "none"})

        if frames % 30 == 0:
            fps = 30.0 / (time.time() - loopTime)
            loopTime = time.time()
            print(f"帧率: {fps:.1f} FPS")

        draw_overlay(out_frame, smooth_info, fps)
        _push_frame(out_frame)   # 将带标注的帧推入 MJPEG 流
        cv2.imshow(out_win, out_frame)

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    print(f"总平均帧率: {frames / (time.time() - initTime):.1f} FPS")
    cap.release()
    cv2.destroyAllWindows()
    pool.release()


if __name__ == "__main__":
    main()
