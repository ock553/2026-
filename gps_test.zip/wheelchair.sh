#!/bin/bash
# 智能轮椅系统 启动/停止脚本
# 用法：./wheelchair.sh start | stop | status | restart

set -euo pipefail

# ── 路径配置 ──────────────────────────────────────────────────
ROS_SETUP=/opt/ros/humble/setup.bash
WS_SETUP=/home/elf/car/install/setup.bash
PID_DIR=/tmp/wheelchair
LOG_DIR=/home/elf/logs

# ── 外设路径 ──────────────────────────────────────────────────
DEV_LIDAR=/dev/wheeltec_lidar
DEV_IMU=/dev/HFRobotIMU
DEV_CAM=/dev/video21
DEV_GPS=/dev/ttyS3

# ── 颜色输出 ──────────────────────────────────────────────────
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
BLUE='\033[0;34m'; NC='\033[0m'

info()  { echo -e "${BLUE}[INFO]${NC}  $*"; }
ok()    { echo -e "${GREEN}[OK]${NC}    $*"; }
warn()  { echo -e "${YELLOW}[WARN]${NC}  $*"; }
error() { echo -e "${RED}[ERROR]${NC} $*"; }

# ── source ROS 环境 ───────────────────────────────────────────
_source_ros() {
    set +u
    source "$ROS_SETUP"
    if [ -f "$WS_SETUP" ]; then
        source "$WS_SETUP"
    else
        # setup.bash不存在时从运行中的ROS节点继承环境变量
        local ref_pid
        ref_pid=$(pgrep -f "pose_node\|web_node\|llm_node" 2>/dev/null | head -1)
        if [ -n "$ref_pid" ] && [ -f "/proc/$ref_pid/environ" ]; then
            while IFS='=' read -r key val; do
                case "$key" in
                    AMENT_PREFIX_PATH|COLCON_PREFIX_PATH|PYTHONPATH|LD_LIBRARY_PATH|ROS_DISTRO|ROS_VERSION|ROS_PYTHON_VERSION|ROS_LOCALHOST_ONLY)
                        export "$key=$val" ;;
                esac
            done < <(cat /proc/$ref_pid/environ | tr '\0' '\n')
        fi
    fi
    export LD_LIBRARY_PATH=/home/elf/demo_Linux_aarch64/lib:${LD_LIBRARY_PATH:-}
    set -u
}

# ── 检查外设 ──────────────────────────────────────────────────
_check_devices() {
    local fail=0
    for dev in "$DEV_LIDAR" "$DEV_IMU" "$DEV_CAM" "$DEV_GPS"; do
        if [ -e "$dev" ]; then
            ok "外设就绪：$dev"
        else
            error "外设缺失：$dev"
            fail=1
        fi
    done
    if [ $fail -eq 1 ]; then error "外设检查未通过，终止启动"; exit 1; fi
}

# ── 后台启动 launch，记录 PID ─────────────────────────────────
_launch() {
    local name=$1
    local pkg=$2
    local launch_file=$3
    local log="$LOG_DIR/${name}.log"
    local pid_file="$PID_DIR/${name}.pid"

    info "启动 $name ..."
    _source_ros

    setsid ros2 launch "$pkg" "$launch_file" \
        >> "$log" 2>&1 &
    local pid=$!
    echo $pid > "$pid_file"
    ok "$name 已启动 (PID=$pid，日志：$log)"
}

# ── 停止单个服务 ──────────────────────────────────────────────
_stop_one() {
    local name=$1
    local pid_file="$PID_DIR/${name}.pid"

    if [ ! -f "$pid_file" ]; then
        warn "$name PID文件不存在，跳过"
        return
    fi

    local pid
    pid=$(cat "$pid_file")

    if kill -0 "$pid" 2>/dev/null; then
        info "停止 $name (PID=$pid) ..."
        kill -- -"$pid" 2>/dev/null || kill "$pid" 2>/dev/null || true
        local i=0
        while kill -0 "$pid" 2>/dev/null && [ $i -lt 5 ]; do
            sleep 1; i=$((i+1))
        done
        if kill -0 "$pid" 2>/dev/null; then
            warn "$name 未响应，强制终止"
            kill -9 -- -"$pid" 2>/dev/null || kill -9 "$pid" 2>/dev/null || true
        fi
        ok "$name 已停止"
    else
        warn "$name 进程不存在（可能已退出）"
    fi

    rm -f "$pid_file"
}

# ════════════════════════════════════════════════════════════
#  START
# ════════════════════════════════════════════════════════════
cmd_start() {
    echo ""
    echo -e "${BLUE}══════════════════════════════════════${NC}"
    echo -e "${BLUE}   智能轮椅系统 启动中...              ${NC}"
    echo -e "${BLUE}══════════════════════════════════════${NC}"

    if [ -f "$PID_DIR/slam.pid" ] && kill -0 "$(cat $PID_DIR/slam.pid)" 2>/dev/null; then
        warn "系统已在运行，请先执行 stop"
        exit 1
    fi

    mkdir -p "$PID_DIR" "$LOG_DIR"

    # 1. 检查外设
    echo ""
    info "[ 1/5 ] 检查外设..."
    _check_devices

    # 2. SLAM（激光雷达 + IMU + Cartographer）
    echo ""
    info "[ 2/5 ] 启动 SLAM（激光雷达 + IMU + Cartographer）..."
    _launch slam car_slam slam_launch.py
    info "等待 SLAM 初始化（8秒）..."
    sleep 8

    # 3. 视觉姿态检测
    echo ""
    info "[ 3/5 ] 启动视觉姿态检测（摄像头 + NPU）..."
    _launch vision car_vision vision_launch.py
    sleep 2

    # 4. Web服务（独立启动，不依赖 LLM）
    echo ""
    info "[ 4/5 ] 启动 Web服务节点..."
    _launch web car_llm web_launch.py
    sleep 2

    # 5. LLM推理（可选，失败不影响 Web 数据流）
    echo ""
    info "[ 5/5 ] 启动 LLM推理节点..."
    _launch llm car_llm llm_launch.py || warn "llm_node 启动异常，Web 数据流不受影响"
    sleep 2

    echo ""
    echo -e "${GREEN}══════════════════════════════════════${NC}"
    echo -e "${GREEN}   系统启动完成                        ${NC}"
    echo -e "${GREEN}══════════════════════════════════════${NC}"
    echo ""
    echo -e "  监护网页：${BLUE}http://10.255.219.24${NC}"
    echo -e "  日志目录：${BLUE}$LOG_DIR${NC}"
    echo ""
}

# ════════════════════════════════════════════════════════════
#  STOP
# ════════════════════════════════════════════════════════════
cmd_stop() {
    echo ""
    echo -e "${YELLOW}══════════════════════════════════════${NC}"
    echo -e "${YELLOW}   智能轮椅系统 关闭中...              ${NC}"
    echo -e "${YELLOW}══════════════════════════════════════${NC}"
    echo ""

    # 反序停止
    _stop_one llm
    sleep 1
    _stop_one web
    sleep 1
    _stop_one vision
    sleep 1
    _stop_one slam

    # 清理所有残余 ROS2 进程
    info "清理残余进程..."
    pkill -f "ros2 launch"                 2>/dev/null || true
    pkill -f "cartographer_node"           2>/dev/null || true
    pkill -f "cartographer_occupancy_grid" 2>/dev/null || true
    pkill -f "lslidar_driver_node"         2>/dev/null || true
    pkill -f "imu_node"                    2>/dev/null || true
    pkill -f "imu_filter_madgwick_node"    2>/dev/null || true
    pkill -f "pose_node"                   2>/dev/null || true
    pkill -f "llm_node"                    2>/dev/null || true
    pkill -f "web_node"                    2>/dev/null || true
    pkill -f "uvicorn"                     2>/dev/null || true

    sleep 1
    ok "所有外设已释放"
    rm -rf "$PID_DIR"

    echo ""
    echo -e "${YELLOW}══════════════════════════════════════${NC}"
    echo -e "${YELLOW}   系统已完全停止                      ${NC}"
    echo -e "${YELLOW}══════════════════════════════════════${NC}"
    echo ""
}

# ════════════════════════════════════════════════════════════
#  STATUS
# ════════════════════════════════════════════════════════════
cmd_status() {
    echo ""
    echo -e "${BLUE}═══ 节点状态 ═══${NC}"
    for name in slam vision web llm; do
        local pid_file="$PID_DIR/${name}.pid"
        if [ -f "$pid_file" ] && kill -0 "$(cat $pid_file)" 2>/dev/null; then
            echo -e "  ${name}: ${GREEN}运行中${NC} (PID=$(cat $pid_file))"
        else
            echo -e "  ${name}: ${RED}已停止${NC}"
        fi
    done

    echo ""
    echo -e "${BLUE}═══ 外设状态 ═══${NC}"
    for dev in "$DEV_LIDAR" "$DEV_IMU" "$DEV_CAM" "$DEV_GPS"; do
        if [ -e "$dev" ]; then
            echo -e "  $dev: ${GREEN}就绪${NC}"
        else
            echo -e "  $dev: ${RED}缺失${NC}"
        fi
    done
    echo ""
}

# ════════════════════════════════════════════════════════════
#  入口
# ════════════════════════════════════════════════════════════
case "${1:-}" in
    start)   cmd_start  ;;
    stop)    cmd_stop   ;;
    status)  cmd_status ;;
    restart) cmd_stop; sleep 2; cmd_start ;;
    *)
        echo "用法: $0 {start|stop|restart|status}"
        exit 1
        ;;
esac
