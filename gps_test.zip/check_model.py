"""
验证 best.rknn 模型的实际输出格式
运行：python3 check_model.py
"""
import numpy as np
from rknnlite.api import RKNNLite

MODEL_PATH = "/home/elf/best.rknn"

rknn = RKNNLite()
if rknn.load_rknn(MODEL_PATH) != 0:
    print("模型加载失败"); exit(1)
if rknn.init_runtime(core_mask=RKNNLite.NPU_CORE_0) != 0:
    print("运行时初始化失败"); exit(1)

# 随机输入（全零也行）
dummy = np.zeros((1, 640, 640, 3), dtype=np.uint8)
outputs = rknn.inference(inputs=[dummy], data_format=['nhwc'])

print(f"\n输出张量数量: {len(outputs)}")
for i, o in enumerate(outputs):
    print(f"  outputs[{i}].shape = {o.shape}  dtype={o.dtype}")

rknn.release()
