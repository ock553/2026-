#!/usr/bin/env python3
"""从 /map 话题保存一帧 OccupancyGrid 为 PGM + YAML。"""
import sys
import math
import struct
import threading
import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, DurabilityPolicy, HistoryPolicy
from nav_msgs.msg import OccupancyGrid

OUTPUT = "/home/elf/map/map"   # 不带后缀

class MapSaver(Node):
    def __init__(self):
        super().__init__("map_saver")
        qos = QoSProfile(
            reliability=ReliabilityPolicy.RELIABLE,
            durability=DurabilityPolicy.TRANSIENT_LOCAL,
            history=HistoryPolicy.KEEP_LAST,
            depth=1,
        )
        self._done = threading.Event()
        self.create_subscription(OccupancyGrid, "/map", self._cb, qos)
        self.get_logger().info("等待 /map 话题...")

    def _cb(self, msg: OccupancyGrid):
        if self._done.is_set():
            return
        self._done.set()

        w = msg.info.width
        h = msg.info.height
        res = msg.info.resolution
        ox = msg.info.origin.position.x
        oy = msg.info.origin.position.y

        # OccupancyGrid → PGM
        # ROS 地图 Y 朝上，PGM 行从上到下，需翻转
        pgm_path = OUTPUT + ".pgm"
        with open(pgm_path, "wb") as f:
            f.write(f"P5\n{w} {h}\n255\n".encode())
            for row in range(h - 1, -1, -1):   # 翻转 Y
                for col in range(w):
                    v = msg.data[row * w + col]
                    if v == -1:
                        pixel = 205   # 未知 → 灰
                    elif v == 0:
                        pixel = 254   # 空闲 → 白
                    else:
                        pixel = 0     # 占用 → 黑
                    f.write(struct.pack("B", pixel))

        # YAML 元数据
        yaml_path = OUTPUT + ".yaml"
        with open(yaml_path, "w") as f:
            f.write(f"image: map.pgm\n")
            f.write(f"resolution: {res}\n")
            f.write(f"origin: [{ox:.6f}, {oy:.6f}, 0.0]\n")
            f.write(f"negate: 0\n")
            f.write(f"occupied_thresh: 0.65\n")
            f.write(f"free_thresh: 0.196\n")

        self.get_logger().info(f"地图已保存：{pgm_path}  {w}x{h} px，分辨率 {res} m/px")


def main():
    rclpy.init()
    node = MapSaver()
    # 等收到一帧地图
    while not node._done.is_set():
        rclpy.spin_once(node, timeout_sec=0.5)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == "__main__":
    main()
