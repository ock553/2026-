#!/usr/bin/env python3
"""
轻量 map_server —— 加载 PGM+YAML 地图，持续发布 /map（TRANSIENT_LOCAL）。
用法：python3 map_server_node.py /home/elf/map/map.yaml
"""
import sys
import struct
import yaml
import os
import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, DurabilityPolicy, HistoryPolicy
from nav_msgs.msg import OccupancyGrid
from geometry_msgs.msg import Pose


def load_pgm(path: str):
    with open(path, "rb") as f:
        magic = f.readline().strip()
        if magic != b"P5":
            raise ValueError(f"不是 PGM P5 格式：{magic}")
        # 跳过注释
        line = f.readline()
        while line.startswith(b"#"):
            line = f.readline()
        w, h = map(int, line.split())
        maxval = int(f.readline().strip())
        raw = f.read()
    return w, h, maxval, raw


def pgm_to_occupancy(w, h, maxval, raw, occ_thresh=0.65, free_thresh=0.196, negate=0):
    data = []
    # PGM 行从上到下，OccupancyGrid 行从下到上 → 翻转 Y
    for row in range(h - 1, -1, -1):
        for col in range(w):
            pixel = raw[row * w + col]
            # 归一化到 [0,1]
            p = pixel / maxval
            if negate:
                p = 1.0 - p
            if p > occ_thresh:
                data.append(100)    # 占用
            elif p < free_thresh:
                data.append(0)      # 空闲
            else:
                data.append(-1)     # 未知
    return data


class MapServerNode(Node):
    def __init__(self, yaml_path: str):
        super().__init__("map_server")

        # 加载 YAML
        with open(yaml_path) as f:
            cfg = yaml.safe_load(f)

        yaml_dir = os.path.dirname(os.path.abspath(yaml_path))
        pgm_path = os.path.join(yaml_dir, cfg["image"])

        res       = float(cfg["resolution"])
        origin    = cfg["origin"]           # [x, y, yaw]
        negate    = int(cfg.get("negate", 0))
        occ_thr   = float(cfg.get("occupied_thresh", 0.65))
        free_thr  = float(cfg.get("free_thresh", 0.196))

        w, h, maxval, raw = load_pgm(pgm_path)
        data = pgm_to_occupancy(w, h, maxval, raw, occ_thr, free_thr, negate)

        # 构造消息
        self._msg = OccupancyGrid()
        self._msg.header.frame_id = "map"
        self._msg.info.resolution = res
        self._msg.info.width  = w
        self._msg.info.height = h
        self._msg.info.origin.position.x = float(origin[0])
        self._msg.info.origin.position.y = float(origin[1])
        self._msg.info.origin.position.z = 0.0
        self._msg.info.origin.orientation.w = 1.0
        self._msg.data = data

        # TRANSIENT_LOCAL：新订阅者立刻收到最新地图
        qos = QoSProfile(
            reliability=ReliabilityPolicy.RELIABLE,
            durability=DurabilityPolicy.TRANSIENT_LOCAL,
            history=HistoryPolicy.KEEP_LAST,
            depth=1,
        )
        self._pub = self.create_publisher(OccupancyGrid, "/map", qos)
        self.create_timer(1.0, self._publish)
        self._publish()

        self.get_logger().info(
            f"地图加载完成：{w}x{h} px，分辨率 {res} m/px，文件：{pgm_path}"
        )

    def _publish(self):
        import rclpy.time
        self._msg.header.stamp = self.get_clock().now().to_msg()
        self._pub.publish(self._msg)


def main():
    yaml_path = sys.argv[1] if len(sys.argv) > 1 else "/home/elf/map/map.yaml"
    rclpy.init()
    node = MapServerNode(yaml_path)
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
