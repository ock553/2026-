"""
调试脚本：打印模型输出每一行的数值分布，找出置信度所在行
"""
import cv2
import numpy as np
from rknnlite.api import RKNNLite

MODEL_PATH = "/home/elf/best.rknn"
CAMERA_ID  = "/dev/video21"

rknn = RKNNLite()
rknn.load_rknn(MODEL_PATH)
rknn.init_runtime(core_mask=RKNNLite.NPU_CORE_0)

cap = cv2.VideoCapture(CAMERA_ID)
ret, frame = cap.read()
cap.release()

# 预处理
img = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
h, w = img.shape[:2]
r = min(640/h, 640/w)
new_w, new_h = int(round(w*r)), int(round(h*r))
img = cv2.resize(img, (new_w, new_h))
pad_w, pad_h = (640-new_w)/2, (640-new_h)/2
top    = int(round(pad_h-0.1))
bottom = int(round(pad_h+0.1))
left   = int(round(pad_w-0.1))
right  = int(round(pad_w+0.1))
img = cv2.copyMakeBorder(img, top, bottom, left, right,
                          cv2.BORDER_CONSTANT, value=(114,114,114))
inp = np.expand_dims(img, 0)

outputs = rknn.inference(inputs=[inp], data_format=['nhwc'])
rknn.release()

data = outputs[0][0]   # (17, 8400)

print("各行数值分布（找置信度在哪一行）：")
print(f"{'行':>3}  {'max':>10}  {'min':>10}  {'mean':>10}  {'>0.1数量':>10}  {'推测含义'}")
print("-" * 70)
for i in range(17):
    row = data[i]
    guess = ""
    if i < 4:
        guess = f"bbox xywh[{i}]"
    elif 0.0 < row.max() <= 1.0 and row.min() >= 0.0:
        guess = "<-- 可能是置信度/关键点置信度"
    elif row.max() > 1.0:
        guess = "<-- 可能是坐标"
    print(f"{i:>3}  {row.max():>10.4f}  {row.min():>10.4f}  {row.mean():>10.4f}  {(row>0.1).sum():>10}  {guess}")
