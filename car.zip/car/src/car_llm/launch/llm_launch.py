import os
from launch import LaunchDescription
from launch.actions import SetEnvironmentVariable
from launch_ros.actions import Node

LIB = '/home/elf'


def generate_launch_description():
    return LaunchDescription([
        SetEnvironmentVariable(
            name='LD_LIBRARY_PATH',
            value=LIB + ':' + os.environ.get('LD_LIBRARY_PATH', '')
        ),
        Node(
            package='car_llm',
            executable='llm_node',
            name='llm_node',
            output='screen',
        ),
    ])
