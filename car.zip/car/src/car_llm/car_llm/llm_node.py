"""
car_llm - 安全规则分析节点（纯规则模式，不依赖 LLM）

订阅：
  /pose/status  (std_msgs/String)   姿态状态 normal/warning/alarm/none
  /pose/angle   (std_msgs/Float32)  前倾角度，-1 表示未检测到
  /gps/latlon   (std_msgs/String)   GPS 坐标 JSON，由 web_node 发布

发布：
  /llm/risk        (std_msgs/String)  规则推理结论 JSON
  /llm/alert_level (std_msgs/Int32)   实时分级 0~3

SLAM 局部坐标通过 TF map→base_link 查询
CSV 日志写入 /home/elf/logs/wheelchair_YYYYMMDD.csv
"""
import csv
import json
import os
import threading
from collections import deque
from datetime import datetime

import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32, String, Int32
import tf2_ros

# ── 配置 ─────────────────────────────────────────────────────
LOG_DIR = "/home/elf/logs"

# 规则分析周期（秒）
INFER_INTERVAL = 10
# 滑动窗口大小（1Hz采样，保留30秒数据）
WINDOW_SIZE = 30


# ── CSV 日志 ──────────────────────────────────────────────────

_CSV_HEADER = [
    "timestamp", "latitude", "longitude",
    "slam_x", "slam_y",
    "angle", "status",
    "llm_level", "llm_type", "llm_confidence", "llm_detail",
]


class DataLogger:
    def __init__(self, log_dir: str):
        os.makedirs(log_dir, exist_ok=True)
        self._dir  = log_dir
        self._lock = threading.Lock()
        self._path = None
        self._file = None
        self._writer = None
        self._open_file()

    def _today_path(self) -> str:
        return os.path.join(self._dir,
               f"wheelchair_{datetime.now().strftime('%Y%m%d')}.csv")

    def _open_file(self):
        path = self._today_path()
        if path == self._path:
            return
        if self._file:
            self._file.close()
        new_file = not os.path.exists(path)
        self._file   = open(path, 'a', newline='', encoding='utf-8')
        self._writer = csv.writer(self._file)
        if new_file:
            self._writer.writerow(_CSV_HEADER)
        self._path = path

    def write(self, row: dict):
        with self._lock:
            self._open_file()
            self._writer.writerow([row.get(k, '') for k in _CSV_HEADER])
            self._file.flush()

    def close(self):
        if self._file:
            self._file.close()


# ── 主节点 ───────────────────────────────────────────────────

class LLMNode(Node):

    def __init__(self):
        super().__init__("llm_node")

        # 传感器状态
        self._pose_status = "none"
        self._pose_angle  = -1.0
        self._state_lock  = threading.Lock()

        # GPS（由 web_node 发布，通过话题接收）
        self._gps_lat  = None
        self._gps_lon  = None
        self._gps_lock = threading.Lock()

        # 滑动窗口
        self._window = deque(maxlen=WINDOW_SIZE)
        self._win_lock = threading.Lock()

        # 最新 LLM 结论
        self._last_risk = {"level": 0, "type": "safe",
                           "confidence": 0.0, "detail": ""}
        self._risk_lock = threading.Lock()

        # TF
        self._tf_buf = tf2_ros.Buffer()
        self._tf_listener = tf2_ros.TransformListener(self._tf_buf, self)

        # CSV 日志
        self._csv_logger = DataLogger(LOG_DIR)

        # 发布者
        self.pub_risk        = self.create_publisher(String, "/llm/risk",        10)
        self.pub_alert_level = self.create_publisher(Int32,  "/llm/alert_level", 10)

        # 订阅者
        self.create_subscription(String,  "/pose/status", self._cb_status, 10)
        self.create_subscription(Float32, "/pose/angle",  self._cb_angle,  10)
        self.create_subscription(String,  "/gps/latlon",  self._cb_gps,    10)

        # 1 Hz 采样 + 记录
        self.create_timer(1.0, self._tick_sample)

        # 推理定时器
        self._infer_countdown = INFER_INTERVAL
        self.create_timer(1.0, self._tick_infer)

        self.get_logger().info("llm_node 启动（纯规则分析模式，10秒周期）")

    # ── 话题回调 ─────────────────────────────────────────────

    def _cb_status(self, msg: String):
        with self._state_lock:
            self._pose_status = msg.data

    def _cb_angle(self, msg: Float32):
        with self._state_lock:
            self._pose_angle = msg.data

    def _cb_gps(self, msg: String):
        try:
            d = json.loads(msg.data)
            with self._gps_lock:
                self._gps_lat = d["lat"]
                self._gps_lon = d["lon"]
        except Exception:
            pass

    # ── TF 查询位置 ───────────────────────────────────────────

    def _get_slam_pos(self):
        try:
            t = self._tf_buf.lookup_transform(
                'map', 'base_link', rclpy.time.Time())
            return (round(t.transform.translation.x, 3),
                    round(t.transform.translation.y, 3))
        except Exception:
            return (None, None)

    # ── 简单姿态分级（规则，1Hz实时）────────────────────────────

    def _pose_level(self, status: str) -> int:
        return {"alarm": 3, "warning": 2, "normal": 0, "none": 0}.get(status, 0)

    # ── 1Hz 采样：记录当前状态 ──────────────────────────────────

    def _tick_sample(self):
        with self._state_lock:
            status = self._pose_status
            angle  = self._pose_angle

        with self._gps_lock:
            lat = self._gps_lat
            lon = self._gps_lon

        slam_x, slam_y = self._get_slam_pos()
        now_str    = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        level      = self._pose_level(status)

        point = {
            "ts":     now_str,
            "lat":    lat,
            "lon":    lon,
            "slam_x": slam_x,
            "slam_y": slam_y,
            "angle":  angle,
            "status": status,
            "level":  level,
        }

        with self._win_lock:
            self._window.append(point)

        # 发布实时分级
        msg = Int32()
        msg.data = level
        self.pub_alert_level.publish(msg)

        # 写 CSV
        with self._risk_lock:
            risk = dict(self._last_risk)
        self._csv_logger.write({
            "timestamp":      now_str,
            "latitude":       f"{lat:.7f}" if lat else "",
            "longitude":      f"{lon:.7f}" if lon else "",
            "slam_x":         slam_x if slam_x is not None else "",
            "slam_y":         slam_y if slam_y is not None else "",
            "angle":          f"{angle:.1f}" if angle >= 0 else "",
            "status":         status,
            "llm_level":      risk["level"],
            "llm_type":       risk["type"],
            "llm_confidence": risk["confidence"],
            "llm_detail":     risk["detail"],
        })

    # ── 规则分析 ──────────────────────────────────────────────

    def _rule_infer(self, window: list) -> dict:
        if not window:
            return {"level": 0, "type": "safe", "confidence": 0.9, "detail": "无传感器数据"}

        angles  = [p["angle"] for p in window if p["angle"] >= 0]
        alarms  = sum(1 for p in window if p["status"] == "alarm")
        warns   = sum(1 for p in window if p["status"] == "warning")
        max_ang = max(angles) if angles else 0.0
        avg_ang = sum(angles) / len(angles) if angles else 0.0
        n       = len(window)

        # 趋势检测：最近5秒均值 vs 前段均值，差值>5°认为持续上升
        trend_up = False
        if len(angles) >= 10:
            recent  = [p["angle"] for p in window[-5:]  if p["angle"] >= 0]
            earlier = [p["angle"] for p in window[:-5] if p["angle"] >= 0]
            if recent and earlier:
                trend_up = (sum(recent)/len(recent)) - (sum(earlier)/len(earlier)) > 5.0

        if alarms >= 3 or max_ang >= 50:
            return {
                "level": 3, "type": "posture_alarm", "confidence": 0.92,
                "detail": f"持续危险姿态！报警{alarms}次，最大前倾{max_ang:.0f}°，均值{avg_ang:.0f}°"
            }
        if warns >= 5 or max_ang >= 35:
            return {
                "level": 2, "type": "posture_trend", "confidence": 0.82,
                "detail": f"姿态持续恶化，警告{warns}次，最大前倾{max_ang:.0f}°，均值{avg_ang:.0f}°"
            }
        if warns >= 2 or max_ang >= 25 or trend_up:
            detail = f"前倾趋势，最大{max_ang:.0f}°，均值{avg_ang:.0f}°"
            if trend_up:
                detail += "，角度持续增大，请关注"
            return {"level": 1, "type": "posture_notice", "confidence": 0.76, "detail": detail}

        return {
            "level": 0, "type": "safe", "confidence": 0.94,
            "detail": f"{n}秒监测正常，最大前倾{max_ang:.0f}°，均值{avg_ang:.0f}°"
        }

    # ── 分析定时器 ─────────────────────────────────────────────

    def _tick_infer(self):
        self._infer_countdown -= 1
        if self._infer_countdown > 0:
            return
        self._infer_countdown = INFER_INTERVAL

        with self._win_lock:
            window = list(self._window)

        if len(window) < 5:
            return

        risk = self._rule_infer(window)
        self.get_logger().info(
            f"规则分析 → level={risk['level']} type={risk['type']} "
            f"conf={risk['confidence']:.0%} | {risk['detail']}"
        )
        self._publish_risk(risk)

    def _publish_risk(self, risk: dict):
        with self._risk_lock:
            self._last_risk = risk
        out      = String()
        out.data = json.dumps(risk, ensure_ascii=False)
        self.pub_risk.publish(out)

    # ── 销毁 ─────────────────────────────────────────────────

    def destroy_node(self):
        self._csv_logger.close()
        super().destroy_node()


# ── 入口 ─────────────────────────────────────────────────────

def main(args=None):
    rclpy.init(args=args)
    node = LLMNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
