"""
RKLLM ctypes 封装 —— 适配 librkllmrt.so v1.0.1
  - rkllm_init 第二参数是 by-value 结构体（非指针）
  - rkllm_run 参数为 (handle, const char* prompt, userdata)
  - RKLLMParam 包含 num_npu_core，无 skip_special_token/extend_param
  - 回调 state 枚举: NORMAL=0, FINISH=1, ERROR=2
"""
import ctypes
import threading

# ── 枚举常量 ─────────────────────────────────────────────────────
RKLLM_RUN_NORMAL = 0
RKLLM_RUN_FINISH = 1
RKLLM_RUN_ERROR  = 2


# ── 结构体定义 ────────────────────────────────────────────────────

class RKLLMParam(ctypes.Structure):
    """
    v1.0.1 真实布局（来自 rkllm.h）：
      0  : char*  model_path
      8  : int32  num_npu_core   ← 第二字段！
      12 : int32  max_context_len
      16 : int32  max_new_tokens
      20 : int32  top_k
      24 : float  top_p
      28 : float  temperature
      32 : float  repeat_penalty
      36 : float  frequency_penalty
      40 : float  presence_penalty
      44 : int32  mirostat
      48 : float  mirostat_tau
      52 : float  mirostat_eta
      56 : bool   logprobs
      57 : uint8[3] padding
      60 : int32  top_logprobs
      64 : bool   use_gpu
    """
    _fields_ = [
        ("model_path",         ctypes.c_char_p),
        ("num_npu_core",       ctypes.c_int32),
        ("max_context_len",    ctypes.c_int32),
        ("max_new_tokens",     ctypes.c_int32),
        ("top_k",              ctypes.c_int32),
        ("top_p",              ctypes.c_float),
        ("temperature",        ctypes.c_float),
        ("repeat_penalty",     ctypes.c_float),
        ("frequency_penalty",  ctypes.c_float),
        ("presence_penalty",   ctypes.c_float),
        ("mirostat",           ctypes.c_int32),
        ("mirostat_tau",       ctypes.c_float),
        ("mirostat_eta",       ctypes.c_float),
        ("logprobs",           ctypes.c_bool),
        ("_pad",               ctypes.c_uint8 * 3),
        ("top_logprobs",       ctypes.c_int32),
        ("use_gpu",            ctypes.c_bool),
    ]


class RKLLMResult(ctypes.Structure):
    _fields_ = [
        ("text",     ctypes.c_char_p),
        ("token_id", ctypes.c_int32),
    ]


_CB_TYPE = ctypes.CFUNCTYPE(
    None,
    ctypes.POINTER(RKLLMResult),
    ctypes.c_void_p,
    ctypes.c_int32,
)


# ── 封装类 ───────────────────────────────────────────────────────

class RKLLMWrapper:
    """线程安全的 RKLLM 推理封装（适配 v1.0.1 API）。"""

    def __init__(self, lib_path: str, model_path: str,
                 max_context_len: int = 512,
                 max_new_tokens: int = 256,
                 temperature: float = 0.8):

        self._lib = ctypes.CDLL(lib_path)
        self._setup_signatures()

        self._handle   = ctypes.c_void_p(None)
        self._lock     = threading.Lock()
        self._buf      = []
        self._done_evt = threading.Event()
        self._callback = _CB_TYPE(self._on_result)

        param = RKLLMParam()
        param.model_path        = model_path.encode()
        param.max_context_len   = max_context_len
        param.max_new_tokens    = max_new_tokens
        param.top_k             = 1
        param.top_p             = 0.9
        param.temperature       = temperature
        param.repeat_penalty    = 1.1
        param.frequency_penalty = 0.0
        param.presence_penalty  = 0.0
        param.mirostat          = 0
        param.mirostat_tau      = 5.0
        param.mirostat_eta      = 0.1
        param.logprobs          = False
        param.top_logprobs      = 0
        param.num_npu_core      = 3

        # v1.0.1: rkllm_init 第二参数是 RKLLMParam by-value
        ret = self._lib.rkllm_init(
            ctypes.byref(self._handle),
            param,
            self._callback,
        )
        if ret != 0:
            raise RuntimeError(f"rkllm_init 失败，错误码: {ret}")

    def _setup_signatures(self):
        lib = self._lib

        lib.rkllm_init.restype  = ctypes.c_int
        lib.rkllm_init.argtypes = [
            ctypes.POINTER(ctypes.c_void_p),
            RKLLMParam,   # v1.0.1: by-value
            _CB_TYPE,
        ]

        # v1.0.1: rkllm_run(handle, const char* prompt, userdata)
        lib.rkllm_run.restype  = ctypes.c_int
        lib.rkllm_run.argtypes = [
            ctypes.c_void_p,
            ctypes.c_char_p,
            ctypes.c_void_p,
        ]

        lib.rkllm_abort.restype  = ctypes.c_int
        lib.rkllm_abort.argtypes = [ctypes.c_void_p]

        lib.rkllm_destroy.restype  = ctypes.c_int
        lib.rkllm_destroy.argtypes = [ctypes.c_void_p]

    def _on_result(self, result_ptr, _userdata, state):
        if state == RKLLM_RUN_NORMAL:
            if result_ptr and result_ptr.contents.text:
                self._buf.append(
                    result_ptr.contents.text.decode("utf-8", errors="replace")
                )
        elif state in (RKLLM_RUN_FINISH, RKLLM_RUN_ERROR):
            self._done_evt.set()

    def generate(self, prompt: str, timeout: float = 60.0) -> str:
        with self._lock:
            self._buf.clear()
            self._done_evt.clear()

            ret = self._lib.rkllm_run(
                self._handle,
                prompt.encode("utf-8"),
                None,
            )
            if ret != 0:
                return f"[推理失败: {ret}]"

            self._done_evt.wait(timeout=timeout)
            return "".join(self._buf)

    def destroy(self):
        if self._handle:
            self._lib.rkllm_destroy(self._handle)
            self._handle = None
