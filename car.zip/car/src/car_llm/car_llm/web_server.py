"""
FastAPI 后端
  WebSocket /ws      — 实时推送千问推理结论 + 传感器状态
  GET /api/export    — 下载当日 CSV 日志
  GET /api/history   — 查询最近 N 条推理记录（JSON）
  GET /api/status    — 当前传感器快照

启动方式（standalone，不依赖 ROS）：
  uvicorn car_llm.web_server:app --host 0.0.0.0 --port 8000

或由 web_node.py 在 ROS2 节点内启动。
"""
import csv
import glob
import json
import os
from datetime import datetime
from typing import List

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware

LOG_DIR = "/home/elf/logs"

app = FastAPI(title="智能轮椅监护平台")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── 连接管理 ──────────────────────────────────────────────────

class _ConnectionManager:
    def __init__(self):
        self._clients: List[WebSocket] = []

    async def connect(self, ws: WebSocket):
        await ws.accept()
        self._clients.append(ws)

    def disconnect(self, ws: WebSocket):
        if ws in self._clients:
            self._clients.remove(ws)

    async def broadcast(self, data: dict):
        dead = []
        for ws in self._clients:
            try:
                await ws.send_json(data)
            except Exception:
                dead.append(ws)
        for ws in dead:
            self.disconnect(ws)


manager = _ConnectionManager()

# ── 内部推送接口（由 web_node.py 调用）───────────────────────

async def push_event(event_type: str, payload: dict):
    """llm_node 产生新数据时调用此函数广播给所有网页客户端。"""
    await manager.broadcast({
        "type":      event_type,
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "data":      payload,
    })


# ── WebSocket 端点 ────────────────────────────────────────────

@app.websocket("/ws")
async def websocket_endpoint(ws: WebSocket):
    await manager.connect(ws)
    try:
        while True:
            # 保持连接，等待客户端断开
            await ws.receive_text()
    except WebSocketDisconnect:
        manager.disconnect(ws)


# ── REST 接口 ─────────────────────────────────────────────────

@app.get("/api/export")
async def export_csv(date: str = ""):
    """下载 CSV 日志。date 格式 YYYYMMDD，默认今天。"""
    if not date:
        date = datetime.now().strftime("%Y%m%d")
    path = os.path.join(LOG_DIR, f"wheelchair_{date}.csv")
    if not os.path.exists(path):
        return JSONResponse({"error": "日志不存在"}, status_code=404)
    return FileResponse(
        path,
        media_type="text/csv",
        filename=f"wheelchair_report_{date}.csv",
    )


@app.get("/api/history")
async def get_history(limit: int = 50):
    """返回最近 limit 条推理记录（从 CSV 读取）。"""
    today = datetime.now().strftime("%Y%m%d")
    path  = os.path.join(LOG_DIR, f"wheelchair_{today}.csv")
    if not os.path.exists(path):
        return JSONResponse([])

    rows = []
    with open(path, newline='', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            # 只保留有 LLM 结论的行
            if row.get("llm_type") and row["llm_type"] != "safe":
                rows.append(row)

    return JSONResponse(rows[-limit:])


@app.get("/api/logs")
async def list_logs():
    """列出所有可用日志日期。"""
    files = glob.glob(os.path.join(LOG_DIR, "wheelchair_*.csv"))
    dates = [os.path.basename(f).replace("wheelchair_", "").replace(".csv", "")
             for f in sorted(files)]
    return JSONResponse(dates)


@app.get("/api/status")
async def get_status():
    """当前系统状态快照（由 web_node 更新）。"""
    return JSONResponse(_status_snapshot)


# 状态快照，由 web_node.py 更新
_status_snapshot: dict = {
    "pose_status": "none",
    "pose_angle":  -1.0,
    "latitude":    None,
    "longitude":   None,
    "slam_x":      None,
    "slam_y":      None,
    "alert_level": 0,
    "llm_ready":   False,
}


def update_status(patch: dict):
    _status_snapshot.update(patch)
