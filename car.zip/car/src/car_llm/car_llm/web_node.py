"""
web_node — ROS2 节点，在同一进程内启动 FastAPI，
把 /llm/risk、/pose/status、/pose/angle、/llm/alert_level、/map
实时广播给网页 WebSocket 客户端。

GPS 直接读取串口 /dev/ttyS3，并同时发布 /gps/latlon 供 llm_node 订阅。
"""
import asyncio
import base64
import json
import math
import serial
import threading
import time

import cv2
import numpy as np
import rclpy
import rclpy.time
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, DurabilityPolicy, HistoryPolicy
from std_msgs.msg import Float32, String, Int32
from nav_msgs.msg import OccupancyGrid
from tf2_ros import Buffer, TransformListener, LookupException, ExtrapolationException
import uvicorn

from car_llm.web_server import app, push_event, update_status

GPS_PORT = "/dev/ttyS3"
GPS_BAUD = 9600


# ── NMEA 解析 ──────────────────────────────────────────────────

def _nmea_ok(line: str) -> bool:
    if '*' not in line:
        return False
    try:
        data, chk = line[1:].rsplit('*', 1)
        calc = 0
        for c in data:
            calc ^= ord(c)
        return calc == int(chk.strip(), 16)
    except Exception:
        return False


def _ddmm_to_deg(raw: str, hemi: str) -> float:
    if not raw:
        return float('nan')
    dot = raw.index('.')
    deg = float(raw[:dot - 2])
    minutes = float(raw[dot - 2:])
    result = deg + minutes / 60.0
    if hemi in ('S', 'W'):
        result = -result
    return result


def _parse_nmea(line: str):
    line = line.strip()
    if not line.startswith('$') or not _nmea_ok(line):
        return None
    clean  = line.split('*')[0]
    fields = clean.split(',')
    tag    = fields[0][1:]
    if tag in ('GPGGA', 'GNGGA') and len(fields) >= 10:
        if not fields[6] or fields[6] == '0':
            return None
        return (_ddmm_to_deg(fields[2], fields[3]),
                _ddmm_to_deg(fields[4], fields[5]))
    if tag in ('GPRMC', 'GNRMC') and len(fields) >= 7:
        if fields[2] != 'A':
            return None
        return (_ddmm_to_deg(fields[3], fields[4]),
                _ddmm_to_deg(fields[5], fields[6]))
    return None


class WebNode(Node):

    def __init__(self):
        super().__init__("web_node")

        self._loop = asyncio.new_event_loop()
        threading.Thread(target=self._start_server, daemon=True).start()

        self.create_subscription(String,        "/llm/risk",        self._cb_risk,    10)
        self.create_subscription(String,        "/pose/status",     self._cb_status,  10)
        self.create_subscription(Float32,       "/pose/angle",      self._cb_angle,   10)
        self.create_subscription(Int32,         "/llm/alert_level", self._cb_level,   10)
        self.create_subscription(String,        "/pose/frame_b64",  self._cb_frame,    1)

        # Cartographer 用 TRANSIENT_LOCAL 发布 /map，订阅必须匹配否则收不到
        _map_qos = QoSProfile(
            reliability=ReliabilityPolicy.RELIABLE,
            durability=DurabilityPolicy.TRANSIENT_LOCAL,
            history=HistoryPolicy.KEEP_LAST,
            depth=1,
        )
        self.create_subscription(OccupancyGrid, "/map", self._cb_slam_map, _map_qos)

        # 发布 GPS 话题供 llm_node 订阅
        self.pub_gps = self.create_publisher(String, "/gps/latlon", 10)

        # TF 监听：定时获取 map→base_link 位姿
        self._tf_buf = Buffer()
        self._tf_listener = TransformListener(self._tf_buf, self)
        self.create_timer(0.5, self._pub_slam_pose)

        # GPS 串口读取线程
        threading.Thread(target=self._gps_loop, daemon=True).start()

        self.get_logger().info("web_node 启动，监听 http://0.0.0.0:8000")

    def _start_server(self):
        asyncio.set_event_loop(self._loop)
        config = uvicorn.Config(app, host="0.0.0.0", port=8000, log_level="warning")
        server = uvicorn.Server(config)
        self._loop.run_until_complete(server.serve())

    def _push(self, event_type: str, payload: dict):
        asyncio.run_coroutine_threadsafe(
            push_event(event_type, payload), self._loop
        )

    # ── GPS 串口读取 ─────────────────────────────────────────────

    def _gps_loop(self):
        while True:
            try:
                ser = serial.Serial(GPS_PORT, GPS_BAUD, timeout=2.0)
                buf = b""
                while True:
                    buf += ser.read(256)
                    while b'\n' in buf:
                        line_b, buf = buf.split(b'\n', 1)
                        line = line_b.decode('ascii', errors='ignore')
                        result = _parse_nmea(line)
                        if result:
                            lat, lon = result
                            update_status({"latitude": lat, "longitude": lon})
                            # 推送给网页
                            self._push("gps", {"lat": lat, "lon": lon})
                            # 发布 ROS 话题供 llm_node 使用
                            gps_msg = String()
                            gps_msg.data = json.dumps({"lat": lat, "lon": lon})
                            self.pub_gps.publish(gps_msg)
            except Exception as e:
                self.get_logger().warn(f"GPS 串口异常: {e}，3秒后重连")
                time.sleep(3)

    # ── 话题回调 ─────────────────────────────────────────────────

    def _cb_risk(self, msg: String):
        try:
            data = json.loads(msg.data)
        except Exception:
            data = {"raw": msg.data}
        update_status({"llm_level": data.get("level", 0), "llm_type": data.get("type", "")})
        self._push("inference", data)

    def _cb_status(self, msg: String):
        update_status({"pose_status": msg.data})
        self._push("status", {"pose_status": msg.data})

    def _cb_angle(self, msg: Float32):
        update_status({"pose_angle": round(msg.data, 1)})
        self._push("angle", {"pose_angle": round(msg.data, 1)})

    def _cb_level(self, msg: Int32):
        update_status({"alert_level": msg.data})
        self._push("alert_level", {"alert_level": msg.data})

    def _cb_frame(self, msg: String):
        self._push("frame", {"b64": msg.data})

    # ── SLAM 地图 ────────────────────────────────────────────────

    def _cb_slam_map(self, msg: OccupancyGrid):
        try:
            arr = np.array(msg.data, dtype=np.int8).reshape(
                msg.info.height, msg.info.width
            )
            # 地板平面图配色：未知=中灰，自由=近白，障碍=近黑
            img = np.full((msg.info.height, msg.info.width), 195, dtype=np.uint8)
            img[arr == 0]   = 248   # 自由区域：近白
            img[arr == 100] = 28    # 障碍/墙壁：近黑
            partial = (arr > 0) & (arr < 100)
            if partial.any():
                t = arr[partial].astype(np.float32) / 100.0
                img[partial] = np.clip(248 - t * 220, 28, 248).astype(np.uint8)

            img = cv2.flip(img, 0)

            # PNG 无损编码，消除 JPEG 压缩伪影
            _, buf = cv2.imencode('.png', img, [cv2.IMWRITE_PNG_COMPRESSION, 6])
            b64 = base64.b64encode(buf.tobytes()).decode('utf-8')

            self._push('slam_map', {
                'b64':        b64,
                'width':      msg.info.width,
                'height':     msg.info.height,
                'resolution': msg.info.resolution,
                'origin_x':   msg.info.origin.position.x,
                'origin_y':   msg.info.origin.position.y,
            })
        except Exception as e:
            self.get_logger().warn(f'slam_map encode error: {e}')

    def _pub_slam_pose(self):
        try:
            t = self._tf_buf.lookup_transform(
                'map', 'base_link', rclpy.time.Time()
            )
            x   = t.transform.translation.x
            y   = t.transform.translation.y
            qz  = t.transform.rotation.z
            qw  = t.transform.rotation.w
            yaw = 2.0 * math.atan2(qz, qw)
            update_status({'slam_x': round(x, 3), 'slam_y': round(y, 3)})
            self._push('slam_pose', {
                'x':   round(x,   3),
                'y':   round(y,   3),
                'yaw': round(yaw, 4),
            })
        except (LookupException, ExtrapolationException):
            pass
        except Exception as e:
            self.get_logger().warn(f'slam_pose TF error: {e}')


def main(args=None):
    rclpy.init(args=args)
    node = WebNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
