from launch import LaunchDescription
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory
import os


def generate_launch_description():
    config = os.path.join(
        get_package_share_directory('car_camera'), 'config', 'camera.yaml'
    )

    return LaunchDescription([

        # 静态 TF：base_link → camera_link
        Node(
            package='tf2_ros',
            executable='static_transform_publisher',
            name='base_to_camera',
            arguments=['0.1', '0.0', '0.3', '0', '0', '0', 'base_link', 'camera_link']
        ),

        # 绿联摄像头驱动节点（v4l2_camera）
        Node(
            package='v4l2_camera',
            executable='v4l2_camera_node',
            name='camera',
            output='screen',
            parameters=[{
                'video_device': '/dev/video21',
                'image_size': [1280, 720],
                'time_per_frame': [1, 30],
                'pixel_format': 'MJPG',
                'camera_frame_id': 'camera_link',
            }],
            remappings=[
                ('image_raw', '/camera/image_raw'),
                ('camera_info', '/camera/camera_info'),
            ]
        ),
    ])
