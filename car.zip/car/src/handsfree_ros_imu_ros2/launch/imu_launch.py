from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    return LaunchDescription([
        DeclareLaunchArgument('port', default_value='/dev/HFRobotIMU',
                              description='IMU 串口号'),
        DeclareLaunchArgument('baudrate', default_value='921600',
                              description='IMU 波特率'),
        DeclareLaunchArgument('gra_normalization', default_value='true',
                              description='重力加速度归一化'),
        DeclareLaunchArgument('x_reverse', default_value='false',
                              description='左右颠倒时置 true，X 轴额外取反'),

        Node(
            package='handsfree_ros_imu_ros2',
            executable='imu_node',
            name='imu',
            output='screen',
            parameters=[{
                'port': LaunchConfiguration('port'),
                'baudrate': LaunchConfiguration('baudrate'),
                'gra_normalization': LaunchConfiguration('gra_normalization'),
                'x_reverse': LaunchConfiguration('x_reverse'),
            }]
        ),
    ])
