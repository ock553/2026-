from setuptools import setup
import os
from glob import glob

package_name = 'handsfree_ros_imu_ros2'

setup(
    name=package_name,
    version='0.1.0',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages', ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        (os.path.join('share', package_name, 'launch'), glob('launch/*.py')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='HandsFree',
    maintainer_email='hands_free@126.com',
    description='HandsFree ROS2 IMU 驱动（A9型号）',
    license='BSD',
    entry_points={
        'console_scripts': [
            'imu_node = handsfree_ros_imu_ros2.imu_node:main',
        ],
    },
)
