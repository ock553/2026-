#!/usr/bin/env python3
# -*- coding:utf-8 -*-
import serial
import struct
import math
import platform
import serial.tools.list_ports
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Imu
from sensor_msgs.msg import MagneticField


# 欧拉角转四元数（替代 ROS1 tf.transformations）
def quaternion_from_euler(roll, pitch, yaw):
    cy = math.cos(yaw * 0.5)
    sy = math.sin(yaw * 0.5)
    cp = math.cos(pitch * 0.5)
    sp = math.sin(pitch * 0.5)
    cr = math.cos(roll * 0.5)
    sr = math.sin(roll * 0.5)
    q = [0.0] * 4
    q[0] = sr * cp * cy - cr * sp * sy  # x
    q[1] = cr * sp * cy + sr * cp * sy  # y
    q[2] = cr * cp * sy - sr * sp * cy  # z
    q[3] = cr * cp * cy + sr * sp * sy  # w
    return q


# 查找 ttyUSB* 设备
def find_ttyUSB():
    print('IMU 默认串口为 /dev/ttyUSB0，若有多个串口设备请在 launch 文件中指定串口号')
    posts = [port.device for port in serial.tools.list_ports.comports() if 'USB' in port.device or 'ACM' in port.device]
    print("当前连接 {} 个串口设备：{}".format(len(posts), posts))


# crc 校验
def checkSum(list_data, check_data):
    data = bytearray(list_data)
    crc = 0xFFFF
    for pos in data:
        crc ^= pos
        for i in range(8):
            if (crc & 1) != 0:
                crc >>= 1
                crc ^= 0xA001
            else:
                crc >>= 1
    return hex(((crc & 0xff) << 8) + (crc >> 8)) == hex(check_data[0] << 8 | check_data[1])


# 16 进制转 ieee 浮点数
def hex_to_ieee(raw_data):
    ieee_data = []
    raw_data.reverse()
    for i in range(0, len(raw_data), 4):
        data2str = (hex(raw_data[i] | 0xff00)[4:6] + hex(raw_data[i + 1] | 0xff00)[4:6] +
                    hex(raw_data[i + 2] | 0xff00)[4:6] + hex(raw_data[i + 3] | 0xff00)[4:6])
        ieee_data.append(struct.unpack('>f', bytes.fromhex(data2str))[0])
    ieee_data.reverse()
    return ieee_data


class ImuNode(Node):
    def __init__(self):
        super().__init__('imu')

        # 参数声明
        self.declare_parameter('port', '/dev/ttyUSB0')
        self.declare_parameter('baudrate', 921600)
        self.declare_parameter('gra_normalization', True)
        # 倒置安装修正：IMU 绕 X 轴旋转 180° 安装，Y/Z 轴数据取反
        self.declare_parameter('x_reverse', False)  # 左右颠倒时置 True，X 轴额外取反

        self.port = self.get_parameter('port').get_parameter_value().string_value
        self.baudrate = self.get_parameter('baudrate').get_parameter_value().integer_value
        self.gra_normalization = self.get_parameter('gra_normalization').get_parameter_value().bool_value
        self.x_reverse = self.get_parameter('x_reverse').get_parameter_value().bool_value

        # 话题发布
        self.imu_pub = self.create_publisher(Imu, 'handsfree/imu', 10)
        self.mag_pub = self.create_publisher(MagneticField, 'handsfree/mag', 10)

        # 状态变量
        self.buff = {}
        self.key = 0
        self.angle_degree = [0.0, 0.0, 0.0]
        self.magnetometer = [0.0, 0.0, 0.0]
        self.acceleration = [0.0, 0.0, 0.0]
        self.angularVelocity = [0.0, 0.0, 0.0]
        self.pub_flag = [True, True]
        self.data_right_count = 0
        self.imu_serial = None

        self.get_logger().info('IMU 节点启动，串口：%s，波特率：%d' % (self.port, self.baudrate))
        find_ttyUSB()

        # 定时器驱动主循环
        self.timer = self.create_timer(0.0001, self.timer_callback)

    def open_serial(self):
        try:
            self.imu_serial = serial.Serial(port=self.port, baudrate=self.baudrate, timeout=0.5)
            if self.imu_serial.isOpen():
                self.get_logger().info('\033[32m串口成功打开：%s\033[0m' % self.port)
            else:
                self.imu_serial.open()
                self.get_logger().info('\033[32m串口成功打开：%s\033[0m' % self.port)
        except Exception as e:
            self.get_logger().error('串口打开失败：%s，原因：%s' % (self.port, str(e)))
            if self.imu_serial is not None:
                self.imu_serial.close()
            self.imu_serial = None

    def timer_callback(self):
        if self.imu_serial is None:
            self.open_serial()
            return

        try:
            buff_count = self.imu_serial.inWaiting()
            if buff_count > 0:
                buff_data = self.imu_serial.read(buff_count)
                for i in range(buff_count):
                    self.handleSerialData(buff_data[i])
        except (serial.SerialException, IOError) as e:
            self.get_logger().error('串口错误：%s，准备重连' % str(e))
            if self.imu_serial is not None:
                self.imu_serial.close()
            self.imu_serial = None

    def handleSerialData(self, raw_data):
        if self.data_right_count > 200000:
            self.get_logger().error('设备数据持续错误，退出')
            rclpy.shutdown()
            return

        self.buff[self.key] = raw_data
        self.key += 1

        if self.buff[0] != 0xaa:
            self.data_right_count += 1
            self.key = 0
            return
        if self.key < 3:
            return
        if self.buff[1] != 0x55:
            self.key = 0
            return
        if self.key < self.buff[2] + 5:
            return

        self.data_right_count = 0
        data_buff = list(self.buff.values())

        if self.buff[2] == 0x2c and self.pub_flag[0]:
            if checkSum(data_buff[2:47], data_buff[47:49]):
                data = hex_to_ieee(data_buff[7:47])
                self.angularVelocity = data[1:4]
                self.acceleration = data[4:7]
                self.magnetometer = data[7:10]
            else:
                self.get_logger().warn('0x2c 校验失败')
            self.pub_flag[0] = False
        elif self.buff[2] == 0x14 and self.pub_flag[1]:
            if checkSum(data_buff[2:23], data_buff[23:25]):
                data = hex_to_ieee(data_buff[7:23])
                self.angle_degree = data[1:4]
            else:
                self.get_logger().warn('0x14 校验失败')
            self.pub_flag[1] = False
        else:
            self.get_logger().warn('未知数据类型：' + str(self.buff[2]))
            self.buff = {}
            self.key = 0

        self.buff = {}
        self.key = 0
        self.pub_flag[0] = self.pub_flag[1] = True

        stamp = self.get_clock().now().to_msg()

        imu_msg = Imu()
        imu_msg.header.stamp = stamp
        imu_msg.header.frame_id = 'imu_link'

        mag_msg = MagneticField()
        mag_msg.header.stamp = stamp
        mag_msg.header.frame_id = 'imu_link'

        # ── 倒置安装修正（绕 X 轴 180°）──────────────────────────────
        # acc/gyro: Y、Z 轴取反；若左右颠倒则 X 轴额外取反
        x_sign = -1.0 if self.x_reverse else 1.0

        angle_radian = [self.angle_degree[i] * math.pi / 180 for i in range(3)]
        # 原代码标准安装：euler(roll, -pitch, -yaw)
        # 倒置后 Y/Z 翻转，pitch/yaw 双重取反抵消；roll 因旋转方向反转需取反
        # 若左右颠倒（X 也反转），pitch 方向再反一次
        qua = quaternion_from_euler(
            -angle_radian[0],               # roll 取反（倒置）
            x_sign * angle_radian[1],       # pitch：左右颠倒时取反
            x_sign * angle_radian[2]        # yaw：左右颠倒时取反
        )

        imu_msg.orientation.x = qua[0]
        imu_msg.orientation.y = qua[1]
        imu_msg.orientation.z = qua[2]
        imu_msg.orientation.w = qua[3]

        # 角速度：Y、Z 取反；左右颠倒时 X 额外取反
        imu_msg.angular_velocity.x = x_sign * self.angularVelocity[0]
        imu_msg.angular_velocity.y = -self.angularVelocity[1]
        imu_msg.angular_velocity.z = -self.angularVelocity[2]

        acc_k = math.sqrt(self.acceleration[0] ** 2 + self.acceleration[1] ** 2 + self.acceleration[2] ** 2)
        if acc_k == 0:
            acc_k = 1

        # 线加速度：Y、Z 取反；左右颠倒时 X 额外取反
        if self.gra_normalization:
            imu_msg.linear_acceleration.x = x_sign * self.acceleration[0] * 9.8 / acc_k
            imu_msg.linear_acceleration.y = -self.acceleration[1] * 9.8 / acc_k
            imu_msg.linear_acceleration.z = -self.acceleration[2] * 9.8 / acc_k
        else:
            imu_msg.linear_acceleration.x = x_sign * self.acceleration[0] * 9.8
            imu_msg.linear_acceleration.y = -self.acceleration[1] * 9.8
            imu_msg.linear_acceleration.z = -self.acceleration[2] * 9.8

        mag_msg.magnetic_field.x = x_sign * self.magnetometer[0]
        mag_msg.magnetic_field.y = -self.magnetometer[1]
        mag_msg.magnetic_field.z = -self.magnetometer[2]

        self.imu_pub.publish(imu_msg)
        self.mag_pub.publish(mag_msg)


def main(args=None):
    rclpy.init(args=args)
    node = ImuNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        if node.imu_serial is not None:
            node.imu_serial.close()
        node.get_logger().info('IMU 驱动已关闭')
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
