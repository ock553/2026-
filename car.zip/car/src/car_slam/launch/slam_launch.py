import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, TimerAction, ExecuteProcess
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node, LifecycleNode

MAP_YAML = "/home/elf/map/map.yaml"
_USE_SAVED_MAP = os.path.exists(MAP_YAML)


def generate_launch_description():
    use_sim_time = LaunchConfiguration('use_sim_time', default='false')

    cartographer_config_dir = os.path.join(
        get_package_share_directory('car_slam'), 'config'
    )
    lidar_config = os.path.join(
        get_package_share_directory('lslidar_driver'), 'params', 'lidar_uart_ros2', 'lsn10.yaml'
    )

    # ── 激光雷达 + 静态 TF（无论哪种模式都需要）─────────────────
    common_nodes = [
        DeclareLaunchArgument('use_sim_time', default_value='false'),

        LifecycleNode(
            package='lslidar_driver',
            executable='lslidar_driver_node',
            name='lslidar_driver_node',
            output='screen',
            emulate_tty=True,
            namespace='',
            parameters=[lidar_config, {'serial_port_': '/dev/wheeltec_lidar'}],
        ),

        Node(
            package='tf2_ros',
            executable='static_transform_publisher',
            name='base_to_laser',
            arguments=['0.0', '0.0', '0.1', '0', '0', '0', 'base_link', 'laser']
        ),
        Node(
            package='tf2_ros',
            executable='static_transform_publisher',
            name='base_to_imu',
            arguments=['0.0', '0.0', '0.05', '0', '0', '0', 'base_link', 'imu_link']
        ),
    ]

    if _USE_SAVED_MAP:
        # ── 已有地图：加载静态地图 + 发布固定 TF ────────────────
        print(f"[slam_launch] 加载已保存地图：{MAP_YAML}")
        return LaunchDescription(common_nodes + [

            # 静态地图服务（直接运行 Python 脚本）
            ExecuteProcess(
                cmd=['python3', '/home/elf/map/map_server_node.py', MAP_YAML],
                output='screen',
                name='map_server',
            ),

            # 固定 map→odom→base_link TF（静态定位，不移动）
            Node(
                package='tf2_ros',
                executable='static_transform_publisher',
                name='map_to_odom',
                arguments=['0', '0', '0', '0', '0', '0', 'map', 'odom']
            ),
            Node(
                package='tf2_ros',
                executable='static_transform_publisher',
                name='odom_to_base',
                arguments=['0', '0', '0', '0', '0', '0', 'odom', 'base_link']
            ),
        ])
    else:
        # ── 无地图：实时 Cartographer 建图 ──────────────────────
        print("[slam_launch] 未找到地图文件，启动 Cartographer 实时建图")
        return LaunchDescription(common_nodes + [

            TimerAction(period=5.0, actions=[
                Node(
                    package='handsfree_ros_imu_ros2',
                    executable='imu_node',
                    name='imu',
                    output='screen',
                    parameters=[{
                        'port': '/dev/HFRobotIMU',
                        'baudrate': 921600,
                        'gra_normalization': True,
                    }]
                ),
                Node(
                    package='imu_filter_madgwick',
                    executable='imu_filter_madgwick_node',
                    name='imu_filter',
                    output='screen',
                    remappings=[
                        ('imu/data_raw', '/handsfree/imu'),
                        ('imu/mag',      '/handsfree/mag'),
                    ],
                    parameters=[{
                        'use_mag': True,
                        'publish_tf': False,
                        'world_frame': 'enu',
                        'gain': 0.1,
                    }]
                ),
            ]),

            Node(
                package='cartographer_ros',
                executable='cartographer_node',
                name='cartographer_node',
                output='screen',
                parameters=[{'use_sim_time': use_sim_time}],
                arguments=[
                    '-configuration_directory', cartographer_config_dir,
                    '-configuration_basename', 'n10_cartographer.lua',
                ],
                remappings=[
                    ('scan', '/scan'),
                    ('imu',  '/imu/data'),
                    ('odom', '/odom'),
                ],
            ),

            Node(
                package='cartographer_ros',
                executable='cartographer_occupancy_grid_node',
                name='cartographer_occupancy_grid_node',
                output='screen',
                parameters=[
                    {'use_sim_time': use_sim_time},
                    {'resolution': 0.05},
                    {'publish_period_sec': 1.0},
                ],
            ),
        ])
