-- N10 单线激光雷达 + IMU 融合 2D SLAM 配置
-- 激光雷达：N10，600 RPM = 10 Hz（串口驱动强制设置）
-- IMU：HandsFree，经 Madgwick 滤波后发布 /imu/data

include "map_builder.lua"
include "trajectory_builder.lua"

options = {
  map_builder          = MAP_BUILDER,
  trajectory_builder   = TRAJECTORY_BUILDER,

  -- 坐标系
  map_frame            = "map",
  tracking_frame       = "base_link",  -- IMU 不可用，直接跟踪 base_link
  published_frame      = "base_link",
  odom_frame           = "odom",
  provide_odom_frame   = true,

  -- 传感器配置
  use_odometry         = false,
  use_nav_sat          = false,
  use_landmarks        = false,

  -- 激光雷达
  num_laser_scans                   = 1,
  num_multi_echo_laser_scans        = 0,
  num_subdivisions_per_laser_scan   = 1,
  num_point_clouds                  = 0,

  -- 发布频率
  lookup_transform_timeout_sec      = 0.2,
  submap_publish_period_sec         = 0.3,
  pose_publish_period_sec           = 5e-3,
  trajectory_publish_period_sec     = 30e-3,

  -- 采样率
  rangefinder_sampling_ratio        = 1.0,
  odometry_sampling_ratio           = 1.0,
  fixed_frame_pose_sampling_ratio   = 1.0,
  imu_sampling_ratio                = 1.0,
  landmarks_sampling_ratio          = 1.0,

  publish_frame_projected_to_2d     = false,
}

-- 2D 模式
MAP_BUILDER.use_trajectory_builder_2d = true

-- ── 轨迹构建参数 ──────────────────────────────────────────────────
TRAJECTORY_BUILDER_2D.use_imu_data  = false  -- IMU 串口不稳定，禁用
TRAJECTORY_BUILDER_2D.min_range     = 0.2    -- N10 最小测距
TRAJECTORY_BUILDER_2D.max_range     = 12.0   -- N10 有效测距上限
TRAJECTORY_BUILDER_2D.missing_data_ray_length = 5.0

-- IMU 重力估计时间常数（默认 10s，增大到 100s 使初始化更宽松，防止建图爆炸）
-- 值越大 = 重力方向收敛越慢，但对 IMU 噪声更容忍
TRAJECTORY_BUILDER_2D.imu_gravity_time_constant = 100.

-- 实时相关扫描匹配（手推速度不稳，保持较大搜索窗口）
TRAJECTORY_BUILDER_2D.use_online_correlative_scan_matching = true
TRAJECTORY_BUILDER_2D.real_time_correlative_scan_matcher.linear_search_window  = 0.15
TRAJECTORY_BUILDER_2D.real_time_correlative_scan_matcher.angular_search_window = 0.35
TRAJECTORY_BUILDER_2D.real_time_correlative_scan_matcher.translation_delta_cost_weight = 10.0
TRAJECTORY_BUILDER_2D.real_time_correlative_scan_matcher.rotation_delta_cost_weight    = 1e-1

-- Ceres 扫描匹配权重
-- rotation_weight 从 4e2 降到 2e2：减少对 IMU 旋转的依赖，防止 IMU 误差积累导致爆炸
TRAJECTORY_BUILDER_2D.ceres_scan_matcher.translation_weight = 2e2
TRAJECTORY_BUILDER_2D.ceres_scan_matcher.rotation_weight    = 2e2

-- 子图大小（N10 10Hz，60帧 ≈ 6秒一张子图）
TRAJECTORY_BUILDER_2D.submaps.num_range_data = 60
TRAJECTORY_BUILDER_2D.submaps.grid_options_2d.resolution = 0.05

-- ── 位姿图优化参数 ────────────────────────────────────────────────
POSE_GRAPH.optimize_every_n_nodes = 60
POSE_GRAPH.constraint_builder.sampling_ratio           = 0.003
POSE_GRAPH.constraint_builder.max_constraint_distance  = 15.0
POSE_GRAPH.constraint_builder.min_score                = 0.55
POSE_GRAPH.optimization_problem.huber_scale            = 1e2
POSE_GRAPH.optimization_problem.local_slam_pose_translation_weight = 1e5
POSE_GRAPH.optimization_problem.local_slam_pose_rotation_weight    = 1e5

return options
