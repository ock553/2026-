"""
car_vision - 姿态检测 ROS2 节点
直接读摄像头 + RKNN NPU 推理，发布结果到 ROS2 话题
  /pose/angle     (std_msgs/Float32) 前倾角度，-1 表示未检测到人
  /pose/status    (std_msgs/String)  "normal" | "warning" | "alarm" | "none"
  /pose/frame_b64 (std_msgs/String)  base64 编码的 JPEG 帧（~10fps）
"""
import threading
import math
import time
import base64

import cv2
import numpy as np
import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32, String
from queue import Queue
from concurrent.futures import ThreadPoolExecutor, as_completed
from rknnlite.api import RKNNLite

JPEG_QUALITY  = 70
# 网页帧率节流：每 N 帧推送一次（30fps 摄像头 → ~10fps 网页）
FRAME_PUSH_EVERY = 3


# ─── 参数 ────────────────────────────────────────────────
MODEL_PATH   = "/home/elf/best.rknn"
CAMERA_ID    = "/dev/video21"
TPEs         = 3            # NPU 只有3核，8个实例会争抢（原8）

WARN_ANGLE   = 30.0
ALARM_ANGLE  = 50.0
MIN_BOX_H    = 80           # 降低以减少漏检（原160过高，容易漏人）
MIN_SHO_SPAN = 25           # 肩宽绝对下限（原40）

# best.rknn 经 RKNN 转换后关键点置信度全为 0，无法使用；
# 人体过滤完全依赖几何约束（头肩距、肩宽、宽高比等）。

# 最低几何质量分：低于此值视为背景误检，直接丢弃
MIN_QUALITY  = 0.12
# 最小头肩像素距离（逆letterbox映射回原图后）：过小说明关键点集中在一个区域，不可信
MIN_HEAD_SHO_PX = 20

# 时序平滑参数
EMA_ALPHA    = 0.20         # EMA 权重（降低至0.2，更强平滑）
MAX_JUMP_DEG = 15.0         # 帧间角度跳变阈值（缩小至15°，更激进拒绝噪声）
HOLD_FRAMES  = 12           # 丢失检测后保持上一角度的帧数（延长至12帧）

KPT_NOSE, KPT_LEAR, KPT_LSHO, KPT_RSHO = 0, 1, 2, 3


# ─── RKNN 线程池 ─────────────────────────────────────────

def _initRKNN(model, core_id):
    rknn = RKNNLite()
    if rknn.load_rknn(model) != 0:
        raise RuntimeError("RKNN model load failed")
    core_map = {0: RKNNLite.NPU_CORE_0,
                1: RKNNLite.NPU_CORE_1,
                2: RKNNLite.NPU_CORE_2}
    if rknn.init_runtime(core_mask=core_map[core_id % 3]) != 0:
        raise RuntimeError("RKNN runtime init failed")
    return rknn

class rknnPoolExecutor:
    def __init__(self, model, tpes, func):
        self.tpes     = tpes
        self.queue    = Queue()
        self.pool_list = [_initRKNN(model, i) for i in range(tpes)]
        self.executor  = ThreadPoolExecutor(max_workers=tpes)
        self.func      = func
        self.num       = 0

    def put(self, frame):
        self.queue.put(self.executor.submit(
            self.func, self.pool_list[self.num % self.tpes], frame))
        self.num += 1

    def get(self):
        if self.queue.empty():
            return None, False
        temp = [self.queue.get()]
        for f in as_completed(temp):
            return f.result(), True

    def release(self):
        self.executor.shutdown()
        for r in self.pool_list:
            r.release()


# ─── 预处理 ──────────────────────────────────────────────

def letterbox(im, size=640):
    h, w = im.shape[:2]
    r = min(size / h, size / w)
    nw, nh = int(round(w * r)), int(round(h * r))
    im = cv2.resize(im, (nw, nh), interpolation=cv2.INTER_LINEAR)
    dw, dh = (size - nw) / 2, (size - nh) / 2
    top    = int(round(dh - 0.1));  bottom = int(round(dh + 0.1))
    left   = int(round(dw - 0.1));  right  = int(round(dw + 0.1))
    im = cv2.copyMakeBorder(im, top, bottom, left, right,
                             cv2.BORDER_CONSTANT, value=(114, 114, 114))
    return im, r, (left, top)


# ─── 后处理 ──────────────────────────────────────────────

def postprocess(outputs, ratio, pad, orig_shape):
    d = outputs[0][0]
    nose_y = d[6]; lear_y = d[9]
    lsho_x = d[11]; lsho_y = d[12]
    rsho_x = d[14]; rsho_y = d[15]

    head_y    = np.minimum(nose_y, lear_y)
    mid_sho_y = (lsho_y + rsho_y) * 0.5

    sho_span  = np.abs(lsho_x - rsho_x)
    head_gap  = mid_sho_y - head_y
    sho_level = np.abs(lsho_y - rsho_y)

    # 头部必须在框的上半部分（排除头部预测点落在框下半的背景误检）
    head_in_upper = head_y < (d[1] - d[3] * 0.05)

    # 宽高比：坐姿人体框高≥宽（排除横向环境结构如墙面、桌面）
    aspect_ok = (d[2] / (d[3] + 1e-6)) < 1.6

    # 仅使用几何约束过滤（RKNN转换后关键点置信度全为0，不可用）
    valid = (
        (d[3] >= MIN_BOX_H)             &
        (head_y < mid_sho_y)            &
        (head_gap  > d[3] * 0.10)       &
        (sho_level < d[3] * 0.18)       &
        (sho_span  > MIN_SHO_SPAN)      &
        (sho_span  > d[2] * 0.12)       &
        head_in_upper                   &
        aspect_ok
    )
    if not valid.any():
        return None

    # 用头肩比质量分选框，而不是面积（面积会偏向背景大框）
    head_ratio = np.where(valid, head_gap / (d[3] + 1e-6), 0.0)
    sho_ratio  = np.where(valid, sho_span / (d[2] + 1e-6), 0.0)
    quality    = head_ratio * 0.6 + sho_ratio * 0.4
    i = int(np.argmax(quality))

    # ── 防线1：质量分下限，过低说明是背景误检 ──────────────────
    if quality[i] < MIN_QUALITY:
        return None

    cx, cy = d[0, i], d[1, i]
    bw, bh = d[2, i], d[3, i]

    # ── 防线2：鼻子必须在框的合理区域内 ──────────────────────
    # 水平：框宽 ±60%；垂直：鼻子必须在框上 75% 以内（不能在下半）
    nose_x_raw, nose_y_raw = d[5, i], d[6, i]
    if not ((cx - bw * 0.8) <= nose_x_raw <= (cx + bw * 0.8) and
            nose_y_raw <= (cy + bh * 0.25)):
        return None

    r, (pl, pt) = ratio, pad
    oh, ow = orig_shape[:2]
    box = [
        int(max(0,  (cx - bw*0.5 - pl) / r)),
        int(max(0,  (cy - bh*0.5 - pt) / r)),
        int(min(ow, (cx + bw*0.5 - pl) / r)),
        int(min(oh, (cy + bh*0.5 - pt) / r)),
    ]
    kpts = [((d[5+k*3,i]-pl)/r, (d[6+k*3,i]-pt)/r) for k in range(4)]
    return {'box': box, 'kpts': kpts}


# ─── 前倾角计算 ──────────────────────────────────────────

def calc_lean_angle(kpts):
    nose = kpts[KPT_NOSE]
    lsho, rsho = kpts[KPT_LSHO], kpts[KPT_RSHO]
    mid_x = (lsho[0] + rsho[0]) * 0.5
    mid_y = (lsho[1] + rsho[1]) * 0.5
    hx, hy = nose[0], nose[1]
    if hy >= mid_y:
        return None
    dx, dy = hx - mid_x, hy - mid_y
    dist = math.hypot(dx, dy)
    # ── 防线3：头肩像素距离过小，说明关键点都挤在同一区域，不可信 ──
    if dist < MIN_HEAD_SHO_PX:
        return None
    return math.degrees(math.acos(max(-1.0, min(1.0, (-dy) / dist))))


# ─── 推理函数 ────────────────────────────────────────────

def infer_func(rknn_lite, frame):
    img = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    img, ratio, pad = letterbox(img)
    outputs = rknn_lite.inference(inputs=[np.expand_dims(img, 0)],
                                  data_format=['nhwc'])
    det = postprocess(outputs, ratio, pad, frame.shape)
    if det is None:
        return frame, None

    kpts = det['kpts']

    kpt_colors = [(0,255,255), (0,200,255), (0,255,0), (0,255,0)]
    for k, (kx, ky) in enumerate(kpts):
        cv2.circle(frame, (int(kx), int(ky)), 7, kpt_colors[k], -1)

    lsho, rsho = kpts[2], kpts[3]
    nose = kpts[0]
    mid = (int((lsho[0]+rsho[0])/2), int((lsho[1]+rsho[1])/2))
    cv2.line(frame, (int(lsho[0]),int(lsho[1])), (int(rsho[0]),int(rsho[1])), (0,255,0), 2)
    cv2.line(frame, (int(nose[0]),int(nose[1])), mid, (255,200,0), 2)

    angle = calc_lean_angle(kpts)
    if angle is not None:
        if angle >= ALARM_ANGLE:
            color, label = (0,0,255), f"报警! {angle:.0f}deg"
        elif angle >= WARN_ANGLE:
            color, label = (0,100,255), f"警告 {angle:.0f}deg"
        else:
            color, label = (0,200,0), f"正常 {angle:.0f}deg"
        cv2.putText(frame, label, (det['box'][0], det['box'][1]-8),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.9, color, 2)

    return frame, angle




# ─── ROS2 节点 ───────────────────────────────────────────

class PoseNode(Node):
    def __init__(self):
        super().__init__('pose_node')

        self.pub_angle  = self.create_publisher(Float32, '/pose/angle',     10)
        self.pub_status = self.create_publisher(String, '/pose/status',    10)
        self.pub_frame  = self.create_publisher(String, '/pose/frame_b64', 1)

        self.get_logger().info("初始化 RKNN 线程池...")
        self._pool = rknnPoolExecutor(MODEL_PATH, TPEs, infer_func)
        self.get_logger().info("模型就绪，启动摄像头...")

        self._cap = cv2.VideoCapture(CAMERA_ID, cv2.CAP_V4L2)   # 指定V4L2避免GStreamer失败
        if not self._cap.isOpened():
            self.get_logger().error(f"无法打开摄像头 {CAMERA_ID}")
            return

        # 预填充管道
        for _ in range(TPEs + 1):
            ret, frame = self._cap.read()
            if ret:
                self._pool.put(frame)

        # 推理线程
        self._running = True
        self._thread  = threading.Thread(target=self._infer_loop, daemon=True)
        self._thread.start()
        self.get_logger().info("姿态检测节点启动")

    def _infer_loop(self):
        frames, t0 = 0, time.time()
        push_cnt = 0
        ema_angle = None    # EMA 平滑后的角度
        hold_cnt  = 0       # 检测丢失后的保持帧计数

        while self._running:
            ret, frame = self._cap.read()
            if not ret:
                continue
            self._pool.put(frame)

            result, ok = self._pool.get()
            if not ok:
                continue

            frame, angle = result  # frame 已画好，angle 为 float or None

            # ── 时序平滑：EMA + 跳变拒绝 + 丢失保持 ──────────────
            if angle is not None:
                if ema_angle is None:
                    ema_angle = angle
                else:
                    delta = abs(angle - ema_angle)
                    # 跳变过大时大幅降低新帧权重，避免噪声帧拉偏均值
                    alpha = EMA_ALPHA if delta <= MAX_JUMP_DEG else EMA_ALPHA * 0.15
                    ema_angle = alpha * angle + (1.0 - alpha) * ema_angle
                hold_cnt = HOLD_FRAMES
                angle = ema_angle
            else:
                # 短暂丢失检测时，保持上一次平滑值而不是直接置 -1
                if hold_cnt > 0:
                    hold_cnt -= 1
                    angle = ema_angle
                else:
                    ema_angle = None  # 确实长时间丢失，重置

            # 发布姿态话题
            msg_angle  = Float32()
            msg_status = String()

            if angle is None:
                msg_angle.data  = -1.0
                msg_status.data = "none"
            elif angle >= ALARM_ANGLE:
                msg_angle.data  = float(angle)
                msg_status.data = "alarm"
                self.get_logger().warn(f"前倾报警！角度={angle:.1f}°")
            elif angle >= WARN_ANGLE:
                msg_angle.data  = float(angle)
                msg_status.data = "warning"
            else:
                msg_angle.data  = float(angle)
                msg_status.data = "normal"

            self.pub_angle.publish(msg_angle)
            self.pub_status.publish(msg_status)

            # 节流发布画面帧（~10fps），base64 编码后通过 ROS2 String 话题推送
            push_cnt += 1
            if push_cnt % FRAME_PUSH_EVERY == 0:
                ok_enc, jpg = cv2.imencode('.jpg', frame,
                                           [cv2.IMWRITE_JPEG_QUALITY, JPEG_QUALITY])
                if ok_enc:
                    b64 = base64.b64encode(jpg.tobytes()).decode('ascii')
                    frame_msg = String()
                    frame_msg.data = b64
                    self.pub_frame.publish(frame_msg)

            frames += 1
            if frames % 30 == 0:
                fps = 30.0 / (time.time() - t0)
                t0  = time.time()
                self.get_logger().info(f"FPS={fps:.1f}  angle={angle}")

    def destroy_node(self):
        self._running = False
        self._cap.release()
        self._pool.release()
        super().destroy_node()


# ─── 入口 ────────────────────────────────────────────────

def main(args=None):
    rclpy.init(args=args)
    node = PoseNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
