from launch import LaunchDescription
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory
import os


def generate_launch_description():
    ekf_config = os.path.join(
        get_package_share_directory('car_fusion'), 'config', 'ekf.yaml'
    )

    return LaunchDescription([

        # ── 静态 TF：base_link → laser ─────────────────────────────
        # 激光雷达安装位置（根据实际测量调整 x/y/z 单位:米）
        Node(
            package='tf2_ros',
            executable='static_transform_publisher',
            name='base_to_laser',
            arguments=['0.0', '0.0', '0.1', '0', '0', '0', 'base_link', 'laser']
        ),

        # ── 静态 TF：base_link → imu_link ──────────────────────────
        # IMU 倒置安装，yaw 旋转 3.14159（180°）体现在驱动层已修正
        # 此处 TF 仅描述物理位置偏移
        Node(
            package='tf2_ros',
            executable='static_transform_publisher',
            name='base_to_imu',
            arguments=['0.0', '0.0', '0.05', '0', '0', '0', 'base_link', 'imu_link']
        ),

        # ── Madgwick IMU 滤波器 ─────────────────────────────────────
        # 输入：/imu/data_raw → 输出：/imu/data（附带可靠姿态）
        Node(
            package='imu_filter_madgwick',
            executable='imu_filter_madgwick_node',
            name='imu_filter',
            output='screen',
            remappings=[
                ('imu/data_raw', '/handsfree/imu'),
                ('imu/mag',      '/handsfree/mag'),
            ],
            parameters=[{
                'use_mag': True,          # 融合磁力计，提升 yaw 精度
                'publish_tf': False,      # TF 由 EKF 统一发布
                'world_frame': 'enu',
                'gain': 0.1,
            }]
        ),

        # ── robot_localization EKF ──────────────────────────────────
        # 输入：/imu/data → 输出：/odom + odom→base_link TF
        Node(
            package='robot_localization',
            executable='ekf_node',
            name='ekf_node',
            output='screen',
            parameters=[ekf_config],
            remappings=[
                ('odometry/filtered', '/odom'),
            ]
        ),
    ])
