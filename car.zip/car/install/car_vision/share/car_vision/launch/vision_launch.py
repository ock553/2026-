from launch import LaunchDescription
from launch_ros.actions import Node


def generate_launch_description():
    return LaunchDescription([
        Node(
            package='car_vision',
            executable='pose_node',
            name='pose_node',
            output='screen',
        ),
    ])
